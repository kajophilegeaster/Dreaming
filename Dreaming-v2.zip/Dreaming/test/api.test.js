'use strict';
// Tests d'intégration : nécessitent une vraie base PostgreSQL (TEST_DATABASE_URL).
process.env.NODE_ENV = 'test';
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || process.env.DATABASE_URL;
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-test-secret-test-secret-123';
process.env.BCRYPT_COST = '4';
process.env.AUTH_RATE_MAX = '1000';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../src/server');
const { migrate } = require('../src/migrate');
const { pool } = require('../src/db');

let server, base;

/** Mini client HTTP qui garde les cookies (une "session" par instance). */
class Client {
  constructor() { this.cookie = ''; }
  async req(method, path, body, headers = {}) {
    const h = { ...headers };
    if (body !== undefined) h['Content-Type'] = 'application/json';
    if (this.cookie) h.Cookie = this.cookie;
    const res = await fetch(base + path, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
    const set = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    for (const c of set) {
      const pair = c.split(';')[0];
      if (/=$/.test(pair) || /Expires=Thu, 01 Jan 1970/i.test(c)) this.cookie = '';
      else this.cookie = pair;
    }
    let data = null;
    try { data = await res.json(); } catch (_) { /* pas de JSON */ }
    return { status: res.status, data, headers: res.headers, setCookie: set };
  }
}

const email = (n) => `${n}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}@test.dev`;
const PW = 'un-mot-de-passe-solide';

before(async () => {
  await migrate();
  await pool.query('TRUNCATE users CASCADE');
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(async () => { server.close(); await pool.end(); });

async function signup(name = 'u') {
  const c = new Client();
  const e = email(name);
  const r = await c.req('POST', '/api/auth/register', { email: e, password: PW, displayName: name });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  return { c, email: e };
}

test('inscription : cookie httpOnly + SameSite=Strict, 8 catégories par défaut, pas de hash exposé', async () => {
  const c = new Client();
  const r = await c.req('POST', '/api/auth/register', { email: email('a'), password: PW, displayName: 'Alice' });
  assert.equal(r.status, 201);
  assert.match(r.setCookie[0], /HttpOnly/i);
  assert.match(r.setCookie[0], /SameSite=Strict/i);
  assert.equal(JSON.stringify(r.data).includes('password'), false);
  assert.equal(r.data.user.displayName, 'Alice');
  const cats = await c.req('GET', '/api/categories');
  assert.equal(cats.data.categories.length, 8);
});

test('inscription : validations (e-mail, mot de passe court, doublon)', async () => {
  const c = new Client();
  assert.equal((await c.req('POST', '/api/auth/register', { email: 'pasunmail', password: PW })).status, 400);
  assert.equal((await c.req('POST', '/api/auth/register', { email: email('b'), password: 'court' })).status, 400);
  const e = email('dup');
  assert.equal((await c.req('POST', '/api/auth/register', { email: e, password: PW })).status, 201);
  const again = await new Client().req('POST', '/api/auth/register', { email: e.toUpperCase(), password: PW });
  assert.equal(again.status, 409);
});

test('connexion : mauvais mot de passe et e-mail inconnu donnent le même message', async () => {
  const { email: e } = await signup('login');
  const c = new Client();
  const bad = await c.req('POST', '/api/auth/login', { email: e, password: 'mauvais-mot-de-passe' });
  const unknown = await c.req('POST', '/api/auth/login', { email: email('nobody'), password: PW });
  assert.equal(bad.status, 401);
  assert.equal(unknown.status, 401);
  assert.equal(bad.data.error.message, unknown.data.error.message);
  const ok = await c.req('POST', '/api/auth/login', { email: e, password: PW });
  assert.equal(ok.status, 200);
  assert.equal((await c.req('GET', '/api/auth/me')).status, 200);
});

test('routes protégées : 401 sans session, après déconnexion, et avec un faux cookie', async () => {
  const c = new Client();
  assert.equal((await c.req('GET', '/api/dreams')).status, 401);
  const { c: s } = await signup('out');
  assert.equal((await s.req('GET', '/api/dreams')).status, 200);
  await s.req('POST', '/api/auth/logout', {});
  assert.equal((await s.req('GET', '/api/dreams')).status, 401);
  const fake = new Client();
  fake.cookie = 'dreaming_session=abc.def.ghi';
  assert.equal((await fake.req('GET', '/api/dreams')).status, 401);
});

test('CRUD des rêves + date de réalisation automatique', async () => {
  const { c } = await signup('crud');
  const cats = (await c.req('GET', '/api/categories')).data.categories;
  const voyages = cats.find((x) => x.label === 'Voyages');

  const created = await c.req('POST', '/api/dreams', { title: '  Voir les aurores  ', categoryId: voyages.id, priority: 'haute', plannedDate: '2027-02-15', note: 'Islande' });
  assert.equal(created.status, 201);
  const d = created.data.dream;
  assert.equal(d.title, 'Voir les aurores');
  assert.equal(d.plannedDate, '2027-02-15');
  assert.equal(d.isDone, false);
  assert.equal(d.doneAt, null);

  const done = await c.req('PATCH', `/api/dreams/${d.id}`, { isDone: true, memory: 'Magique' });
  assert.equal(done.status, 200);
  assert.equal(done.data.dream.isDone, true);
  assert.match(done.data.dream.doneAt, /^\d{4}-\d{2}-\d{2}$/);

  const undone = await c.req('PATCH', `/api/dreams/${d.id}`, { isDone: false });
  assert.equal(undone.data.dream.doneAt, null);

  const list = await c.req('GET', '/api/dreams?q=aurore');
  assert.equal(list.data.dreams.length, 1);
  assert.equal((await c.req('GET', '/api/dreams?status=done')).data.dreams.length, 0);

  assert.equal((await c.req('DELETE', `/api/dreams/${d.id}`)).status, 200);
  assert.equal((await c.req('DELETE', `/api/dreams/${d.id}`)).status, 404);
});

test('validation des rêves', async () => {
  const { c } = await signup('val');
  assert.equal((await c.req('POST', '/api/dreams', { title: '   ' })).status, 400);
  assert.equal((await c.req('POST', '/api/dreams', { title: 'x'.repeat(161) })).status, 400);
  assert.equal((await c.req('POST', '/api/dreams', { title: 'ok', priority: 'urgente' })).status, 400);
  assert.equal((await c.req('POST', '/api/dreams', { title: 'ok', plannedDate: '2027-02-31' })).status, 400);
  assert.equal((await c.req('POST', '/api/dreams', { title: 'ok', categoryId: 'pas-un-uuid' })).status, 400);
  // une date de réalisation sur un rêve non réalisé est normalisée par la base (remise à vide)
  const normalized = await c.req('POST', '/api/dreams', { title: 'ok', doneAt: '2026-01-01', isDone: false });
  assert.equal(normalized.status, 201);
  assert.equal(normalized.data.dream.doneAt, null);
  assert.equal((await c.req('PATCH', '/api/dreams/not-a-uuid', { title: 'x' })).status, 400);
});

test('isolation : un compte ne voit, ne modifie ni ne supprime les données d\'un autre', async () => {
  const { c: alice } = await signup('alice');
  const { c: bob } = await signup('bob');
  const aCats = (await alice.req('GET', '/api/categories')).data.categories;
  const secret = (await alice.req('POST', '/api/dreams', { title: 'Secret d\'Alice', categoryId: aCats[0].id })).data.dream;

  assert.equal((await bob.req('GET', '/api/dreams')).data.dreams.length, 0);
  assert.equal((await bob.req('PATCH', `/api/dreams/${secret.id}`, { title: 'piraté' })).status, 404);
  assert.equal((await bob.req('DELETE', `/api/dreams/${secret.id}`)).status, 404);
  assert.equal((await bob.req('PATCH', `/api/categories/${aCats[0].id}`, { label: 'piraté' })).status, 404);
  assert.equal((await bob.req('DELETE', `/api/categories/${aCats[0].id}`)).status, 404);
  // Bob tente d'attacher un rêve à une catégorie d'Alice : refusé par la clé étrangère composite
  assert.equal((await bob.req('POST', '/api/dreams', { title: 'vol', categoryId: aCats[0].id })).status, 400);
  // Un user_id glissé dans le corps est ignoré
  const sneaky = await bob.req('POST', '/api/dreams', { title: 'intrus', user_id: secret.id, userId: 'x' });
  assert.equal(sneaky.status, 201);
  assert.equal((await alice.req('GET', '/api/dreams')).data.dreams.length, 1);
  assert.equal((await alice.req('GET', '/api/dreams')).data.dreams[0].title, "Secret d'Alice");
});

test('catégories : suppression d\'une catégorie conserve les rêves', async () => {
  const { c } = await signup('cat');
  const add = await c.req('POST', '/api/categories', { label: 'Sport', emoji: '🏃', hue: 120 });
  assert.equal(add.status, 201);
  assert.equal((await c.req('POST', '/api/categories', { label: 'Sport' })).status, 409);
  const dream = (await c.req('POST', '/api/dreams', { title: 'Marathon', categoryId: add.data.category.id })).data.dream;
  assert.equal((await c.req('DELETE', `/api/categories/${add.data.category.id}`)).status, 200);
  const list = (await c.req('GET', '/api/dreams')).data.dreams;
  assert.equal(list.length, 1);
  assert.equal(list[0].id, dream.id);
  assert.equal(list[0].categoryId, null);
});

test('modification d\'un rêve : changement partiel, déplacement de catégorie, retrait de la catégorie et de la date', async () => {
  const { c } = await signup('edit');
  const cats = (await c.req('GET', '/api/categories')).data.categories;
  const [a, b] = cats;
  const d = (await c.req('POST', '/api/dreams', { title: 'Piano', categoryId: a.id, priority: 'basse', plannedDate: '2027-01-01', note: 'Débutant' })).data.dream;

  // changement partiel : seuls les champs envoyés changent
  const t = await c.req('PATCH', `/api/dreams/${d.id}`, { title: '  Jouer du piano  ' });
  assert.equal(t.status, 200);
  assert.equal(t.data.dream.title, 'Jouer du piano');
  assert.equal(t.data.dream.note, 'Débutant');
  assert.equal(t.data.dream.categoryId, a.id);
  assert.equal(t.data.dream.plannedDate, '2027-01-01');

  // déplacement vers une autre catégorie, puis retrait de la catégorie et de la date
  assert.equal((await c.req('PATCH', `/api/dreams/${d.id}`, { categoryId: b.id })).data.dream.categoryId, b.id);
  const cleared = (await c.req('PATCH', `/api/dreams/${d.id}`, { categoryId: null, plannedDate: null, note: '' })).data.dream;
  assert.equal(cleared.categoryId, null);
  assert.equal(cleared.plannedDate, null);
  assert.equal(cleared.note, '');

  // refus : titre vide, priorité inconnue, corps vide
  assert.equal((await c.req('PATCH', `/api/dreams/${d.id}`, { title: '   ' })).status, 400);
  assert.equal((await c.req('PATCH', `/api/dreams/${d.id}`, { priority: 'urgente' })).status, 400);
  assert.equal((await c.req('PATCH', `/api/dreams/${d.id}`, {})).status, 400);
  assert.equal((await c.req('GET', '/api/dreams')).data.dreams[0].title, 'Jouer du piano');
});

test('modification d\'un rêve : impossible de le lier à la catégorie d\'un autre compte', async () => {
  const { c: alice } = await signup('alice-e');
  const { c: bob } = await signup('bob-e');
  const bobCat = (await bob.req('GET', '/api/categories')).data.categories[0];
  const d = (await alice.req('POST', '/api/dreams', { title: 'Mon rêve' })).data.dream;
  const r = await alice.req('PATCH', `/api/dreams/${d.id}`, { categoryId: bobCat.id });
  assert.equal(r.status, 400);
  assert.equal((await alice.req('GET', '/api/dreams')).data.dreams[0].categoryId, null);
});

test('modification d\'une catégorie : nom, emoji, teinte ; doublon refusé ; les rêves suivent', async () => {
  const { c } = await signup('catedit');
  const [a, b] = (await c.req('GET', '/api/categories')).data.categories;
  const dream = (await c.req('POST', '/api/dreams', { title: 'Un rêve', categoryId: a.id })).data.dream;
  const r = await c.req('PATCH', `/api/categories/${a.id}`, { label: 'Aventures', emoji: '🧭', hue: 200 });
  assert.equal(r.status, 200);
  assert.deepEqual([r.data.category.label, r.data.category.emoji, r.data.category.hue], ['Aventures', '🧭', 200]);
  assert.equal((await c.req('PATCH', `/api/categories/${a.id}`, { label: b.label })).status, 409);
  assert.equal((await c.req('PATCH', `/api/categories/${a.id}`, { hue: 999 })).status, 400);
  assert.equal((await c.req('GET', '/api/dreams')).data.dreams.find((x) => x.id === dream.id).categoryId, a.id);
});

test('export puis import (sans doublons) et import de l\'ancien format v1', async () => {
  const { c } = await signup('exp');
  const cats = (await c.req('GET', '/api/categories')).data.categories;
  await c.req('POST', '/api/dreams', { title: 'Piano', categoryId: cats[3].id, isDone: true, doneAt: '2026-09-01', memory: 'Fait !' });
  await c.req('POST', '/api/dreams', { title: 'Peinture', priority: 'basse' });
  const exp = await c.req('GET', '/api/export');
  assert.equal(exp.status, 200);
  assert.equal(exp.data.dreams.length, 2);
  assert.equal(exp.data.version, 2);

  // Réimport sur le même compte : tout est ignoré (doublons)
  const again = await c.req('POST', '/api/import', exp.data);
  assert.equal(again.data.imported, 0);
  assert.equal(again.data.skipped, 2);

  // Import dans un autre compte
  const { c: other } = await signup('exp2');
  const imp = await other.req('POST', '/api/import', exp.data);
  assert.equal(imp.data.imported, 2);
  const mine = (await other.req('GET', '/api/dreams?status=done')).data.dreams;
  assert.equal(mine.length, 1);
  assert.equal(mine[0].memory, 'Fait !');
  assert.equal(mine[0].doneAt, '2026-09-01');

  // Ancien format (version artifact) : cat = id de catégorie, planned/done
  const v1 = { categories: [{ id: 'voyages', emoji: '✈️', label: 'Voyages' }, { id: 'perso', emoji: '⭐', label: 'Perso' }],
    dreams: [{ id: 'd1', title: 'Islande', cat: 'voyages', priority: 'haute', planned: '2027-02-01', note: '', done: false, doneAt: '', memory: '', createdAt: 1760000000000 },
             { id: 'd2', title: 'Idée', cat: 'perso', done: true, doneAt: '2026-10-01', createdAt: 1760000001000 },
             { title: '' }] };
  const r1 = await other.req('POST', '/api/import', v1);
  assert.equal(r1.data.imported, 2);
  assert.equal(r1.data.skipped, 1);
  const cats2 = (await other.req('GET', '/api/categories')).data.categories.map((x) => x.label);
  assert.ok(cats2.includes('Perso'));
});

test('mot de passe : changement invalide les anciennes sessions', async () => {
  const { c, email: e } = await signup('pw');
  const second = new Client();
  assert.equal((await second.req('POST', '/api/auth/login', { email: e, password: PW })).status, 200);

  assert.equal((await c.req('POST', '/api/auth/password', { current: 'faux-mot-de-passe', next: 'nouveau-mot-de-passe-1' })).status, 403);
  assert.equal((await c.req('POST', '/api/auth/password', { current: PW, next: 'court' })).status, 400);
  assert.equal((await c.req('POST', '/api/auth/password', { current: PW, next: 'nouveau-mot-de-passe-1' })).status, 200);

  assert.equal((await c.req('GET', '/api/auth/me')).status, 200);       // session courante renouvelée
  assert.equal((await second.req('GET', '/api/auth/me')).status, 401);  // autre session coupée
  assert.equal((await new Client().req('POST', '/api/auth/login', { email: e, password: PW })).status, 401);
  assert.equal((await new Client().req('POST', '/api/auth/login', { email: e, password: 'nouveau-mot-de-passe-1' })).status, 200);
});

test('suppression du compte : cascade sur les rêves et catégories', async () => {
  const { c, email: e } = await signup('del');
  await c.req('POST', '/api/dreams', { title: 'À effacer' });
  assert.equal((await c.req('DELETE', '/api/auth/me', { password: 'faux-mot-de-passe-xx' })).status, 403);
  assert.equal((await c.req('DELETE', '/api/auth/me', { password: PW })).status, 200);
  assert.equal((await c.req('GET', '/api/auth/me')).status, 401);
  const left = await pool.query('SELECT (SELECT count(*) FROM dreams d JOIN users u ON u.id = d.user_id WHERE u.email = $1) AS n', [e]);
  assert.equal(Number(left.rows[0].n), 0);
  const orphans = await pool.query('SELECT count(*)::int AS n FROM dreams WHERE user_id NOT IN (SELECT id FROM users)');
  assert.equal(orphans.rows[0].n, 0);
});

test('sécurité HTTP : CSP, JSON obligatoire, Origin croisée refusée, mot de passe jamais en clair en base', async () => {
  const c = new Client();
  const home = await c.req('GET', '/');
  assert.match(home.headers.get('content-security-policy'), /script-src 'self'/);
  assert.match(home.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  assert.equal(home.headers.get('x-powered-by'), null);

  const text = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: '{}' });
  assert.equal(text.status, 415);

  const { c: s, email: e } = await signup('csrf');
  const cross = await s.req('POST', '/api/dreams', { title: 'csrf' }, { Origin: 'https://evil.example' });
  assert.equal(cross.status, 403);

  const bad = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{pas du json' });
  assert.equal(bad.status, 400);

  const row = (await pool.query('SELECT password_hash FROM users WHERE email = $1', [e])).rows[0];
  assert.match(row.password_hash, /^\$2[aby]\$/);
  assert.notEqual(row.password_hash, PW);

  const inj = await s.req('GET', "/api/dreams?q=' OR 1=1 --");
  assert.equal(inj.status, 200);
  const inj2 = await s.req('GET', '/api/dreams?categoryId=1;drop table dreams');
  assert.equal(inj2.status, 400);
});

test('limitation de débit sur la connexion (serveur réel, 3 tentatives max)', async () => {
  const { spawn } = require('node:child_process');
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['src/server.js'], {
    cwd: require('node:path').join(__dirname, '..'),
    env: { ...process.env, PORT: String(port), AUTH_RATE_MAX: '3' },
    stdio: 'ignore',
  });
  try {
    const url = `http://127.0.0.1:${port}`;
    for (let i = 0; i < 50; i++) {
      try { if ((await fetch(url + '/healthz')).ok) break; } catch (_) { /* pas encore prêt */ }
      await new Promise((r) => setTimeout(r, 100));
    }
    const codes = [];
    for (let i = 0; i < 5; i++) {
      const r = await fetch(url + '/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'x@test.dev', password: 'mauvais-mot-de-passe' }),
      });
      codes.push(r.status);
    }
    assert.deepEqual(codes, [401, 401, 401, 429, 429]);
  } finally {
    child.kill();
  }
});
