-- =====================================================================
-- Dreaming : schéma PostgreSQL standard (PostgreSQL 15+, à cause de
-- « ON DELETE SET NULL (colonne) » sur la clé étrangère composite)
-- Idempotent : peut être relancé sans risque (npm run migrate).
-- Les droits d'accès sont appliqués par l'API : chaque requête est
-- filtrée par user_id, et les clés étrangères composites empêchent
-- de mélanger les données de deux comptes.
-- =====================================================================

create or replace function set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ---------------------------------------------------------------------
-- users : comptes (mot de passe haché avec bcrypt, jamais en clair)
-- ---------------------------------------------------------------------
create table if not exists users (
  id             uuid primary key default gen_random_uuid(),
  email          text not null check (char_length(email) between 3 and 254),
  password_hash  text not null,
  display_name   text check (display_name is null or char_length(display_name) between 1 and 60),
  theme          text not null default 'auto' check (theme in ('dark', 'light', 'auto')),
  last_export    date,
  token_version  integer not null default 0,   -- incrémenté au changement de mot de passe
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
-- Les nouveaux comptes suivent le thème de l'appareil (les comptes existants gardent leur choix)
alter table users alter column theme set default 'auto';

create unique index if not exists users_email_key on users (lower(email));

drop trigger if exists users_set_updated_at on users;
create trigger users_set_updated_at before update on users
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------
-- categories : personnalisables par compte
-- ---------------------------------------------------------------------
create table if not exists categories (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references users (id) on delete cascade,
  label       text not null check (char_length(label) between 1 and 40),
  emoji       text not null default '✦' check (char_length(emoji) between 1 and 8),
  hue         smallint not null default 260 check (hue between 0 and 360),
  position    integer not null default 0,
  created_at  timestamptz not null default now(),
  unique (user_id, label),
  unique (user_id, id)    -- cible de la clé étrangère composite de dreams
);
create index if not exists categories_user_idx on categories (user_id, position);

-- ---------------------------------------------------------------------
-- dreams : les rêves
-- ---------------------------------------------------------------------
create table if not exists dreams (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references users (id) on delete cascade,
  category_id   uuid,
  title         text not null check (char_length(btrim(title)) between 1 and 160),
  note          text not null default '' check (char_length(note) <= 2000),
  priority      text not null default 'moyenne' check (priority in ('haute', 'moyenne', 'basse')),
  planned_date  date,
  is_done       boolean not null default false,
  done_at       date,
  memory        text not null default '' check (char_length(memory) <= 2000),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),

  constraint dreams_done_at_consistent check (done_at is null or is_done),

  -- un rêve ne peut référencer qu'une catégorie du même compte
  constraint dreams_category_fk foreign key (user_id, category_id)
    references categories (user_id, id) on delete set null (category_id),

  -- recherche plein texte en français
  search tsvector generated always as (
    to_tsvector('french'::regconfig,
      coalesce(title, '') || ' ' || coalesce(note, '') || ' ' || coalesce(memory, ''))
  ) stored
);

drop trigger if exists dreams_set_updated_at on dreams;
create trigger dreams_set_updated_at before update on dreams
  for each row execute function set_updated_at();

-- Réalisé sans date => date du jour ; non réalisé => pas de date
create or replace function dreams_sync_done_at()
returns trigger language plpgsql as $$
begin
  if new.is_done and new.done_at is null then
    new.done_at = current_date;
  elsif not new.is_done then
    new.done_at = null;
  end if;
  return new;
end;
$$;

drop trigger if exists dreams_sync_done_at on dreams;
create trigger dreams_sync_done_at before insert or update on dreams
  for each row execute function dreams_sync_done_at();

create index if not exists dreams_user_created_idx  on dreams (user_id, created_at desc);
create index if not exists dreams_user_done_idx     on dreams (user_id, is_done, done_at desc);
create index if not exists dreams_user_category_idx on dreams (user_id, category_id);
create index if not exists dreams_search_idx        on dreams using gin (search);
