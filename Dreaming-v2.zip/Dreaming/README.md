# Dreaming

Carnet privé de rêves et d'envies. Backend **Node.js + Express**, base **PostgreSQL**, front en JavaScript pur (aucun framework, aucune dépendance côté navigateur).

## Fonctionnalités

- **Modifier un rêve** : bouton crayon sur chaque ligne, clic sur le titre ou sur un point de l'accueil, ou touche `n` pour en créer un. La feuille permet de changer titre, catégorie, priorité, date, notes, statut « réalisé », date de réalisation et souvenir. « Enregistrer » ne s'active que s'il y a un changement, et fermer avec des modifications non enregistrées prévient d'abord (Ctrl/Cmd + Entrée enregistre depuis un champ de texte).
- **Dupliquer** un rêve et **annuler une suppression** (7 secondes, le rêve revient avec sa date de création d'origine).
- **Modifier une catégorie** : nom, emoji et couleur (Réglages > Catégories). Supprimer une catégorie conserve ses rêves.
- **Accueil** : une grille de points, un point par rêve (plein quand il est réalisé), qui ouvre le rêve au clic.
- **Design** : clair par défaut, thème sombre et automatique, barre latérale sur ordinateur, barre du bas sur mobile.

## Démarrage en local

Prérequis : Node.js 20+ et PostgreSQL 15+.

```bash
# 1. Crée la base
createdb dreaming            # ou via pgAdmin / psql

# 2. Configure
cp .env.example .env         # puis édite DATABASE_URL et JWT_SECRET

# 3. Installe, crée les tables, lance
npm install
npm run migrate
npm run dev                  # http://localhost:3000
```

## Déploiement sur Render

1. Pousse ce dossier sur GitHub.
2. Render > **New > Blueprint** > choisis le dépôt : `render.yaml` crée la base PostgreSQL et le service web, et génère `JWT_SECRET`.
3. Les tables sont créées au démarrage (`npm run migrate` est idempotent).
4. Vérifie sur Render les conditions du plan de base de données choisi (durée, sauvegardes) : une base gratuite peut être limitée dans le temps.

Si tu te connectes à une base via son URL **externe**, ajoute la variable `PGSSL=true`.

## Sécurité

| Sujet | Mise en œuvre |
|---|---|
| Mots de passe | Hachés avec bcrypt (coût 12), jamais stockés ni renvoyés en clair. 10 caractères minimum. |
| Session | JWT dans un cookie `httpOnly` (illisible par JavaScript), `SameSite=Strict`, `Secure` en production, 7 jours. |
| Déconnexion partout | Changer le mot de passe invalide toutes les autres sessions (`token_version`). |
| Isolation des comptes | Chaque requête SQL est filtrée par `user_id`; une clé étrangère composite interdit de lier un rêve à la catégorie d'un autre compte. |
| Injection SQL | Requêtes 100 % paramétrées; les noms de colonnes viennent de listes fixes. |
| XSS | Le front écrit uniquement via `textContent`; CSP stricte (`script-src 'self'`, pas de script ni style inline). |
| CSRF | Cookie `SameSite=Strict` + JSON obligatoire + contrôle de l'en-tête `Origin`. |
| Force brute | Limitation de débit : 20 tentatives / 15 min sur connexion, inscription et changement de mot de passe; 300 requêtes / min sur l'API. |
| Énumération de comptes | Même message et même temps de réponse pour « e-mail inconnu » et « mauvais mot de passe ». |
| En-têtes | `helmet` (CSP, HSTS, `X-Content-Type-Options`, `frame-ancestors 'none'`, etc.). |

Limites connues : pas de vérification d'e-mail ni de réinitialisation de mot de passe par e-mail (il faudrait un service d'envoi). Une limite de 72 octets s'applique aux mots de passe (contrainte de bcrypt).

## API

Toutes les routes sont sous `/api`, en JSON. Hors `/auth/register` et `/auth/login`, une session est requise.

| Méthode | Route | Rôle |
|---|---|---|
| POST | `/auth/register` | Créer un compte (crée 8 catégories par défaut) |
| POST | `/auth/login` · `/auth/logout` | Connexion · déconnexion |
| GET / PATCH / DELETE | `/auth/me` | Profil · modifier prénom/thème · supprimer le compte (mot de passe requis) |
| POST | `/auth/password` | Changer le mot de passe |
| GET / POST | `/dreams` | Lister (`?q=&categoryId=&status=todo\|done&sort=`) · créer |
| PATCH / DELETE | `/dreams/:id` | Modifier · supprimer |
| DELETE | `/dreams` | Supprimer tous mes rêves |
| GET / POST | `/categories` | Lister · créer |
| PATCH / DELETE | `/categories/:id` | Modifier · supprimer (les rêves sont conservés) |
| GET | `/export` | Sauvegarde JSON |
| POST | `/import` | Importer une sauvegarde (sans doublons; accepte aussi l'ancien format de la version artifact) |
| GET | `/healthz` | Santé du service |

## Tests

Les tests d'intégration utilisent une vraie base PostgreSQL **vide dédiée** (ils vident la table `users`) :

```bash
createdb dreaming_test
TEST_DATABASE_URL=postgres://localhost/dreaming_test npm test
```

Ils couvrent l'inscription, la connexion, l'isolation entre comptes, les validations, l'import/export, le changement de mot de passe, la suppression de compte, la CSP, la protection CSRF et la limitation de débit.

## Structure

```
db/schema.sql        schéma PostgreSQL (idempotent)
src/server.js        application Express, sécurité, erreurs
src/routes/          auth, dreams, categories, data (export/import)
public/              front-end (index.html, style.css, app.js, logo.png)
test/api.test.js     tests d'intégration
```
