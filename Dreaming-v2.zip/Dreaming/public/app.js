'use strict';

/* =====================================================================
   Dreaming : front-end. Parle à l'API Node (/api) via un cookie de session
   httpOnly : aucun jeton n'est jamais visible par le JavaScript de la page.
   ===================================================================== */

/* ---------- État ---------- */
let user = null;          // compte connecté (null = écran de connexion)
let categories = [];      // [{id,label,emoji,hue,position}]
let dreams = [];          // [{id,title,cat,priority,planned,note,done,doneAt,memory,createdAt}]
let ready = false;
let booting = true;
let theme = 'auto';
try { theme = localStorage.getItem('dreaming-theme') || 'auto'; } catch (e) { /* stockage indisponible */ }
const ui = {
  tab: 'home', q: '', cat: 'all', status: 'all', sort: 'recent',
  armedWipe: false, revealed: false,
  authMode: 'login', authEmail: '', authName: '', authMsg: '',
};

/* ---------- Utilitaires ---------- */
const $ = (s) => document.querySelector(s);
function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  props = props || {};
  for (const k in props) {
    const v = props[k];
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k === 'value') e.value = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat(Infinity)) {
    if (k === null || k === undefined || k === false) continue;
    e.append(k.nodeType ? k : document.createTextNode(String(k)));
  }
  return e;
}
const P = {
  logo: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.4" fill="currentColor" stroke="none"/>',
  home: '<path d="M4 11l8-7 8 7"/><path d="M6 10v10h12V10"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11"/><path d="M4.5 6h.01M4.5 12h.01M4.5 18h.01"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M21 12.8A8.5 8.5 0 1111.2 3a6.7 6.7 0 009.8 9.8z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2h2"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12h10l1-12M9 7V4h6v3"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
};
function icon(name, size = 22) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', size); s.setAttribute('height', size);
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '1.8');
  s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round'); s.setAttribute('aria-hidden', 'true');
  s.innerHTML = P[name];
  return s;
}
const pad = (n) => String(n).padStart(2, '0');
function today() { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function fmt(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || '');
  if (!m) return '';
  return new Date(+m[1], +m[2] - 1, +m[3]).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
}
function hash(s) { let x = 2166136261; for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return x >>> 0; }
const plural = (n, one, many) => `${n} ${n > 1 ? many : one}`;
let toastTimer;
/** Message bref ; avec `action` ({label, run}) il reste plus longtemps et propose un bouton (ex. Annuler). */
function toast(m, action) {
  const t = $('#toast');
  t.replaceChildren(h('span', { text: m }));
  if (action) {
    t.append(h('button', {
      class: 'toast-act', type: 'button', text: action.label,
      onclick: () => { clearTimeout(toastTimer); t.classList.remove('on', 'act'); action.run(); },
    }));
  }
  t.classList.toggle('act', !!action);
  t.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('on', 'act'), action ? 7000 : 3400);
}
function catOf(id) { return categories.find((c) => c.id === id) || { id: '', emoji: '', label: 'Sans catégorie', hue: 250 }; }
const hueOf = (c) => (typeof c.hue === 'number' ? c.hue : 250);

/* ---------- Client API ---------- */
async function api(method, path, body) {
  const opt = { method, headers: {}, credentials: 'same-origin' };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  let res;
  try { res = await fetch('/api' + path, opt); }
  catch (e) { const err = new Error('Connexion au serveur impossible. Vérifie ta connexion.'); err.network = true; throw err; }
  let data = null;
  if ((res.headers.get('content-type') || '').includes('json')) { try { data = await res.json(); } catch (e) { /* corps vide */ } }
  if (!res.ok) {
    const err = new Error((data && data.error && data.error.message) || 'Une erreur est survenue.');
    err.status = res.status; err.code = data && data.error && data.error.code;
    if (res.status === 401 && user && !path.startsWith('/auth/login')) {
      user = null; categories = []; dreams = []; ready = false;
      ui.authMode = 'login'; ui.authMsg = 'Ta session a expiré. Reconnecte-toi.';
      sheetGuard = null; closeSheet(); render();
    }
    throw err;
  }
  return data;
}
const fromApi = (d) => ({
  id: d.id, title: d.title, cat: d.categoryId || '', priority: d.priority, planned: d.plannedDate || '',
  note: d.note || '', done: !!d.isDone, doneAt: d.doneAt || '', memory: d.memory || '',
  createdAt: Date.parse(d.createdAt) || Date.now(),
});
const toApi = (d) => ({
  title: d.title, categoryId: d.cat || null, priority: d.priority, plannedDate: d.planned || null,
  note: d.note, isDone: d.done, doneAt: d.done ? (d.doneAt || null) : null, memory: d.memory,
});
async function loadAll() {
  const [c, d] = await Promise.all([api('GET', '/categories'), api('GET', '/dreams')]);
  categories = c.categories;
  dreams = d.dreams.map(fromApi);
  ready = true;
}

/* ---------- Thème ---------- */
function effectiveTheme() {
  if (theme !== 'auto') return theme;
  return window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}
function applyTheme() {
  const r = document.documentElement;
  if (theme === 'auto') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', theme);
  const dark = effectiveTheme() === 'dark';
  const b = $('#themeBtn');
  b.replaceChildren(icon(dark ? 'sun' : 'moon', 20));
  b.setAttribute('aria-label', dark ? 'Passer au thème clair' : 'Passer au thème sombre');
}
function setTheme(t) {
  theme = t;
  try { localStorage.setItem('dreaming-theme', t); } catch (e) { /* ignoré */ }
  applyTheme();
  if (user) api('PATCH', '/auth/me', { theme: t }).catch(() => {});
  if (user && ui.tab === 'settings') render();
}

/* ---------- Actions sur les données ---------- */
async function saveDream(d, isNew) {
  try {
    const res = isNew ? await api('POST', '/dreams', toApi(d)) : await api('PATCH', '/dreams/' + d.id, toApi(d));
    const nd = fromApi(res.dream);
    const i = dreams.findIndex((x) => x.id === nd.id);
    if (i >= 0) dreams[i] = nd; else dreams.unshift(nd);
    render();
    return nd;
  } catch (e) { toast(e.message); return null; }
}
/** Supprime un rêve et renvoie ses données (pour pouvoir annuler), ou null en cas d'échec. */
async function removeDream(id) {
  const gone = dreams.find((x) => x.id === id) || null;
  try { await api('DELETE', '/dreams/' + id); dreams = dreams.filter((x) => x.id !== id); render(); return gone; }
  catch (e) { toast(e.message); return null; }
}
/** Annule une suppression : le rêve est recréé avec sa date de création d'origine. */
async function restoreDream(d) {
  try {
    await api('POST', '/import', { dreams: [{
      title: d.title, category: d.cat ? catOf(d.cat).label : '', note: d.note, priority: d.priority,
      plannedDate: d.planned || null, isDone: d.done, doneAt: d.done ? (d.doneAt || null) : null,
      memory: d.memory, createdAt: new Date(d.createdAt).toISOString(),
    }] });
    await loadAll(); render(); toast('Rêve rétabli.');
  } catch (e) { toast(e.message); }
}
async function toggleDone(d) {
  const nd = await saveDream({ ...d, done: !d.done, doneAt: !d.done ? today() : '' }, false);
  if (nd && nd.done) toast('Rêve réalisé, bravo.', { label: 'Ajouter un souvenir', run: () => openSheet(nd) });
}
const SAMPLES = [
  { title: 'Voir les aurores boréales en Islande', cat: 'Voyages', priority: 'haute', planned: '2027-02-15', note: 'Partir en février, loger loin des lumières de la ville.' },
  { title: 'Courir un semi-marathon', cat: 'Défis', priority: 'moyenne', planned: '2027-04-18', note: "Plan d'entraînement sur 12 semaines." },
  { title: 'Lancer mon propre produit en ligne', cat: 'Carrière', priority: 'haute', planned: '', note: 'Choisir une idée, publier une première version.' },
  { title: 'Apprendre à jouer du piano', cat: 'Apprentissage', priority: 'basse', planned: '', note: '' },
  { title: 'Offrir un voyage surprise à mes parents', cat: 'Famille', priority: 'haute', planned: '2027-08-01', note: '' },
  { title: 'Peindre une fresque murale', cat: 'Créatif', priority: 'moyenne', planned: '', note: '' },
  { title: 'Dormir une nuit sous les étoiles dans le désert', cat: 'Voyages', priority: 'moyenne', planned: '', note: '', done: true, memory: 'Un silence incroyable et un ciel infini.' },
];
async function addSamples() {
  const now = Date.now();
  const list = SAMPLES.map((s, i) => ({
    title: s.title, category: s.cat, priority: s.priority, plannedDate: s.planned || null, note: s.note,
    isDone: !!s.done, doneAt: s.done ? today() : null, memory: s.memory || '',
    createdAt: new Date(now - (SAMPLES.length - i) * 1000).toISOString(),
  }));
  try { await api('POST', '/import', { dreams: list }); await loadAll(); render(); toast("Rêves d'exemple ajoutés."); }
  catch (e) { toast(e.message); }
}
async function wipeAll() {
  try { await api('DELETE', '/dreams'); dreams = []; render(); toast('Tous les rêves ont été supprimés.'); }
  catch (e) { toast(e.message); }
}
async function exportJson() {
  try {
    const data = await api('GET', '/export');
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = h('a', { href: url, download: 'dreaming-sauvegarde-' + today() + '.json' });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    const r = await api('PATCH', '/auth/me', { lastExport: today() });
    user = r.user; toast('Sauvegarde téléchargée.'); render();
  } catch (e) { toast(e.message); }
}
async function importFile(file) {
  try {
    const json = JSON.parse(await file.text());
    const r = await api('POST', '/import', json);
    await loadAll(); render();
    let msg = `${plural(r.imported, 'rêve importé', 'rêves importés')}${r.skipped ? `, ${plural(r.skipped, 'ignoré', 'ignorés')}` : ''}.`;
    if (r.categoriesSkipped) msg += ` ${plural(r.categoriesSkipped, 'catégorie non créée', 'catégories non créées')} (limite atteinte).`;
    toast(msg);
  } catch (e) { toast(e instanceof SyntaxError ? 'Fichier illisible : choisis une sauvegarde Dreaming (.json).' : e.message); }
}
async function logout() {
  try { await api('POST', '/auth/logout', {}); } catch (e) { /* on déconnecte quand même côté page */ }
  user = null; categories = []; dreams = []; ready = false; ui.revealed = false;
  ui.authMode = 'login'; ui.authMsg = ''; ui.tab = 'home'; ui.q = ''; ui.cat = 'all'; ui.status = 'all';
  render();
}

/* ---------- Feuilles (dialog) ---------- */
let sheetGuard = null; // () => true si on peut fermer ; sinon prévient d'abord des modifications non enregistrées
function closeSheet() { const s = $('#sheet'); if (s.open) s.close(); }
function requestClose() { if (!sheetGuard || sheetGuard()) closeSheet(); }
/** Prévient une fois quand on ferme avec des modifications non enregistrées. */
function setGuard(isDirty, err) {
  let warned = false;
  sheetGuard = () => {
    if (!isDirty() || warned) return true;
    warned = true;
    err.textContent = 'Modifications non enregistrées. Ferme à nouveau pour les abandonner.';
    return false;
  };
}
function sheetHead(title, sub) {
  return h('div', { class: 'sheet-head' },
    h('div', null, h('h2', { text: title }), sub ? h('p', { class: 'hint', text: sub }) : null),
    h('button', { class: 'iconbtn sm', type: 'button', 'aria-label': 'Fermer', onclick: requestClose }, icon('x', 18)));
}

/** Petit formulaire modal générique (mot de passe, suppression de compte…). */
function openForm({ title, intro, fields, submit, danger, onSubmit }) {
  const sheet = $('#sheet');
  sheetGuard = null;
  const inputs = fields.map((f) => h('input', { class: 'field', id: 'ff-' + f.id, type: f.type || 'text', autocomplete: f.autocomplete || 'off', maxlength: '72', 'aria-label': f.label, placeholder: f.label }));
  const err = h('div', { class: 'err', role: 'alert' });
  const btn = h('button', { class: 'btn ' + (danger ? 'danger solid' : 'primary'), type: 'submit', text: submit });
  const form = h('form', {
    class: 'authform', novalidate: true,
    onsubmit: async (e) => {
      e.preventDefault(); btn.disabled = true; err.textContent = '';
      try { await onSubmit(inputs.map((i) => i.value)); closeSheet(); }
      catch (ex) { err.textContent = ex.message; }
      finally { btn.disabled = false; }
    },
  }, inputs, err, h('div', { class: 'foot-main' }, btn, h('button', { class: 'btn', type: 'button', onclick: closeSheet, text: 'Annuler' })));
  sheet.replaceChildren(h('div', { class: 'sheet-in' }, sheetHead(title, intro), form));
  sheet.showModal();
  if (inputs[0]) inputs[0].focus();
}
function changePassword() {
  openForm({
    title: 'Changer le mot de passe', intro: 'Les autres appareils seront déconnectés.',
    fields: [{ id: 'cur', label: 'Mot de passe actuel', type: 'password', autocomplete: 'current-password' },
             { id: 'new', label: 'Nouveau mot de passe (10 caractères minimum)', type: 'password', autocomplete: 'new-password' }],
    submit: 'Changer le mot de passe',
    onSubmit: async ([cur, next]) => { await api('POST', '/auth/password', { current: cur, next }); toast('Mot de passe modifié.'); },
  });
}
function deleteAccount() {
  openForm({
    title: 'Supprimer mon compte', intro: 'Tous tes rêves et catégories seront effacés définitivement. Cette action est irréversible.',
    fields: [{ id: 'pw', label: 'Confirme avec ton mot de passe', type: 'password', autocomplete: 'current-password' }],
    submit: 'Supprimer définitivement', danger: true,
    onSubmit: async ([pw]) => {
      await api('DELETE', '/auth/me', { password: pw });
      user = null; categories = []; dreams = []; ready = false; ui.authMode = 'register'; ui.authMsg = '';
      render(); toast('Ton compte a été supprimé.');
    },
  });
}

/** Création et modification d'un rêve. */
function openSheet(d) {
  const isNew = !d;
  const cur = d ? { ...d } : {
    id: 'new', title: '', cat: ui.cat !== 'all' ? ui.cat : (categories[0] ? categories[0].id : ''),
    priority: 'moyenne', planned: '', note: '', done: false, doneAt: '', memory: '', createdAt: Date.now(),
  };
  const sheet = $('#sheet');
  const err = h('div', { class: 'err', role: 'alert' });
  const title = h('input', { class: 'field', id: 'f-title', maxlength: '160', placeholder: 'Ce que je veux vivre…', value: cur.title, 'aria-label': 'Titre du rêve' });
  const planned = h('input', { class: 'field', type: 'date', value: cur.planned, 'aria-label': 'Date prévue' });
  const note = h('textarea', { class: 'field', maxlength: '2000', placeholder: 'Détails, idées, liens…', value: cur.note, 'aria-label': 'Notes' });
  const doneAt = h('input', { class: 'field', type: 'date', value: cur.doneAt, 'aria-label': 'Date de réalisation' });
  const memory = h('textarea', { class: 'field', maxlength: '2000', placeholder: "Comment ça s'est passé ?", value: cur.memory, 'aria-label': 'Souvenir' });

  const snapshot = () => JSON.stringify([title.value.trim(), cur.cat, cur.priority, planned.value, note.value.trim(), cur.done, cur.done ? doneAt.value : '', memory.value.trim()]);
  const initial = snapshot();
  const isDirty = () => snapshot() !== initial;
  const saveBtn = h('button', { class: 'btn primary', type: 'button', text: isNew ? 'Ajouter' : 'Enregistrer', onclick: save });
  const refresh = () => { err.textContent = ''; saveBtn.disabled = !isNew && !isDirty(); };

  const catBtns = [];
  const paintCat = () => catBtns.forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.v === cur.cat)));
  categories.concat([{ id: '', emoji: '', label: 'Aucune' }]).forEach((c) => {
    catBtns.push(h('button', { class: 'chip', type: 'button', 'data-v': c.id, text: (c.emoji ? c.emoji + ' ' : '') + c.label, onclick: () => { cur.cat = c.id; paintCat(); refresh(); } }));
  });
  const prBtns = [];
  const paintPr = () => prBtns.forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.v === cur.priority)));
  [['haute', 'Haute'], ['moyenne', 'Moyenne'], ['basse', 'Basse']].forEach(([v, l]) => {
    prBtns.push(h('button', { class: 'chip', type: 'button', 'data-v': v, text: l, onclick: () => { cur.priority = v; paintPr(); refresh(); } }));
  });

  const doneBox = h('div', { class: 'done-box' + (cur.done ? '' : ' hidden') },
    h('label', { class: 'l', text: 'Date de réalisation' }), doneAt,
    h('label', { class: 'l', text: 'Souvenir' }), memory);
  const sw = h('button', {
    class: 'switch', type: 'button', role: 'switch', 'aria-checked': String(cur.done), 'aria-label': 'Rêve réalisé',
    onclick: () => {
      cur.done = !cur.done;
      sw.setAttribute('aria-checked', String(cur.done));
      doneBox.classList.toggle('hidden', !cur.done);
      if (cur.done && !doneAt.value) doneAt.value = today();
      refresh();
    },
  }, h('i'));

  async function save() {
    const t = title.value.trim();
    if (!t) { err.textContent = 'Donne un titre à ce rêve.'; title.focus(); return; }
    const wasDone = !!(d && d.done);
    const n = {
      id: cur.id, title: t, cat: cur.cat, priority: cur.priority, planned: planned.value, note: note.value.trim(),
      done: cur.done, doneAt: cur.done ? (doneAt.value || today()) : '', memory: memory.value.trim(), createdAt: cur.createdAt,
    };
    saveBtn.disabled = true;
    const saved = await saveDream(n, isNew);
    if (!saved) { saveBtn.disabled = false; return; }
    sheetGuard = null; closeSheet();
    toast(saved.done && !wasDone ? 'Rêve réalisé, bravo.' : (isNew ? 'Rêve ajouté.' : 'Modifications enregistrées.'));
  }
  async function duplicate() {
    const t = title.value.trim();
    if (!t) { err.textContent = 'Donne un titre à ce rêve.'; title.focus(); return; }
    const copy = await saveDream({
      ...cur, id: 'new', title: (t + ' (copie)').slice(0, 160), cat: cur.cat, planned: planned.value, note: note.value.trim(),
      done: false, doneAt: '', memory: '',
    }, true);
    if (copy) { sheetGuard = null; closeSheet(); toast('Rêve dupliqué. Renomme-le si besoin.'); openSheet(copy); }
  }
  async function remove() {
    const gone = await removeDream(cur.id);
    if (gone) { sheetGuard = null; closeSheet(); toast('Rêve supprimé.', { label: 'Annuler', run: () => restoreDream(gone) }); }
  }

  title.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
  [note, memory].forEach((t) => t.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); save(); } }));
  [title, planned, note, doneAt, memory].forEach((el) => el.addEventListener('input', refresh));
  paintPr(); paintCat(); refresh();
  setGuard(isDirty, err);

  const side = isNew ? null : h('div', { class: 'foot-side' },
    h('button', { class: 'btn quiet', type: 'button', onclick: duplicate }, icon('copy', 16), 'Dupliquer'),
    h('button', { class: 'btn quiet danger', type: 'button', onclick: remove }, icon('trash', 16), 'Supprimer'));
  sheet.replaceChildren(h('div', { class: 'sheet-in' },
    sheetHead(isNew ? 'Nouveau rêve' : 'Modifier le rêve'),
    h('label', { class: 'l', for: 'f-title', text: 'Titre' }), title,
    h('div', { class: 'l', text: 'Catégorie' }), h('div', { class: 'seg', role: 'group', 'aria-label': 'Catégorie' }, catBtns),
    h('div', { class: 'l', text: 'Priorité' }), h('div', { class: 'seg', role: 'group', 'aria-label': 'Priorité' }, prBtns),
    h('label', { class: 'l', text: 'Date prévue' }), planned,
    h('label', { class: 'l', text: 'Notes' }), note,
    h('div', { class: 'switchrow' }, h('div', null, h('div', { class: 'sw-t', text: 'Réalisé' }), h('div', { class: 'hint', text: 'Ajoute la date et un souvenir.' })), sw),
    doneBox, err,
    h('div', { class: 'foot' },
      h('div', { class: 'foot-main' }, saveBtn, h('button', { class: 'btn', type: 'button', onclick: requestClose, text: 'Annuler' })),
      side)));
  sheet.showModal();
  if (isNew) title.focus();
}

/** Création et modification d'une catégorie (nom, emoji, couleur). */
function openCategorySheet(c) {
  const isNew = !c;
  const cur = c ? { ...c } : { label: '', emoji: '', hue: hash(String(Date.now())) % 360 };
  const sheet = $('#sheet');
  const err = h('div', { class: 'err', role: 'alert' });
  const em = h('input', { class: 'field em', maxlength: '8', placeholder: '🌙', 'aria-label': 'Emoji', value: cur.emoji });
  const lb = h('input', { class: 'field', maxlength: '40', placeholder: 'Nom de la catégorie', 'aria-label': 'Nom de la catégorie', value: cur.label });
  const hue = h('input', { class: 'hue', type: 'range', min: '0', max: '360', step: '1', 'aria-label': 'Couleur', value: String(cur.hue) });
  const preview = h('span', { class: 'pill' });
  const paint = () => {
    preview.style.setProperty('--h', hue.value);
    preview.textContent = ((em.value.trim() || '✦') + ' ' + (lb.value.trim() || 'Aperçu'));
  };
  const snapshot = () => JSON.stringify([em.value.trim(), lb.value.trim(), hue.value]);
  const initial = snapshot();
  const isDirty = () => snapshot() !== initial;
  const saveBtn = h('button', { class: 'btn primary', type: 'button', text: isNew ? 'Ajouter' : 'Enregistrer', onclick: save });
  const refresh = () => { err.textContent = ''; paint(); saveBtn.disabled = !isNew && !isDirty(); };
  [em, lb, hue].forEach((el) => el.addEventListener('input', refresh));
  lb.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); save(); } });

  async function save() {
    const label = lb.value.trim();
    if (!label) { err.textContent = 'Donne un nom à la catégorie.'; lb.focus(); return; }
    const body = { label, emoji: em.value.trim() || '✦', hue: Number(hue.value) };
    saveBtn.disabled = true;
    try {
      const r = isNew ? await api('POST', '/categories', body) : await api('PATCH', '/categories/' + c.id, body);
      const i = categories.findIndex((x) => x.id === r.category.id);
      if (i >= 0) categories[i] = r.category; else categories.push(r.category);
      sheetGuard = null; closeSheet(); render();
      toast(isNew ? 'Catégorie ajoutée.' : 'Catégorie modifiée.');
    } catch (e) { err.textContent = e.message; saveBtn.disabled = false; }
  }
  let armed = false;
  const n = c ? dreams.filter((d) => d.cat === c.id).length : 0;
  const delBtn = isNew ? null : h('button', {
    class: 'btn quiet danger', type: 'button', text: 'Supprimer la catégorie',
    onclick: async () => {
      if (!armed) { armed = true; delBtn.textContent = 'Confirmer la suppression'; return; }
      try {
        await api('DELETE', '/categories/' + c.id);
        categories = categories.filter((x) => x.id !== c.id); if (ui.cat === c.id) ui.cat = 'all';
        dreams = dreams.map((d) => (d.cat === c.id ? { ...d, cat: '' } : d));
        sheetGuard = null; closeSheet(); render(); toast('Catégorie supprimée.');
      } catch (e) { err.textContent = e.message; }
    },
  });
  setGuard(isDirty, err);
  paint(); saveBtn.disabled = !isNew;
  sheet.replaceChildren(h('div', { class: 'sheet-in' },
    sheetHead(isNew ? 'Nouvelle catégorie' : 'Modifier la catégorie'),
    h('div', { class: 'l', text: 'Nom' }), h('div', { class: 'addcat' }, em, lb),
    h('div', { class: 'l', text: 'Couleur' }), hue, h('div', { class: 'previewrow' }, preview),
    isNew || !n ? null : h('p', { class: 'hint', text: `Si tu la supprimes, ${plural(n, 'rêve est conservé', 'rêves sont conservés')} sans catégorie.` }),
    err,
    h('div', { class: 'foot' },
      h('div', { class: 'foot-main' }, saveBtn, h('button', { class: 'btn', type: 'button', onclick: requestClose, text: 'Annuler' })),
      delBtn ? h('div', { class: 'foot-side' }, delBtn) : null)));
  sheet.showModal();
  lb.focus();
}

/* ---------- Composants ---------- */
function pillOf(c) {
  const p = h('span', { class: 'pill', text: (c.emoji ? c.emoji + ' ' : '') + c.label });
  p.style.setProperty('--h', hueOf(c));
  return p;
}
/** Une ligne de rêve : case à cocher, texte (ouvre la modification) et bouton Modifier. */
function dreamRow(d) {
  const c = catOf(d.cat);
  const tick = h('button', {
    class: 'tick', type: 'button', 'aria-pressed': String(!!d.done),
    'aria-label': (d.done ? 'Marquer comme non réalisé : ' : 'Marquer comme réalisé : ') + d.title,
    onclick: () => toggleDone(d),
  }, d.done ? icon('check', 15) : null);
  const when = d.done && d.doneAt ? 'Réalisé le ' + fmt(d.doneAt) : (d.planned ? 'Prévu le ' + fmt(d.planned) : '');
  const meta = h('div', { class: 'meta' },
    d.cat ? pillOf(c) : null,
    h('span', { class: 'prio p-' + (d.priority || 'moyenne') }, h('i', { class: 'pd' }), 'Priorité ' + (d.priority || 'moyenne')),
    when ? h('span', { text: when }) : null);
  const extra = d.done && d.memory ? d.memory : d.note;
  const main = h('button', { class: 'rowmain', type: 'button', 'aria-label': 'Modifier : ' + d.title, onclick: () => openSheet(d) },
    h('span', { class: 't', text: d.title }), meta, extra ? h('span', { class: 'note', text: extra }) : null);
  const edit = h('button', { class: 'iconbtn sm ghost', type: 'button', title: 'Modifier', 'aria-label': 'Modifier : ' + d.title, onclick: () => openSheet(d) }, icon('edit', 17));
  const row = h('div', { class: 'row-item' + (d.done ? ' done' : '') }, tick, main, edit);
  row.addEventListener('click', (e) => { if (!e.target.closest('button')) openSheet(d); });
  return row;
}
const listBox = (items) => h('div', { class: 'list' }, items.map(dreamRow));
function emptyBox(msg, buttons) {
  return h('div', { class: 'empty' }, h('p', { text: msg }), buttons && buttons.length ? h('div', { class: 'btns' }, buttons) : null);
}
const addBtn = (label) => h('button', { class: 'btn primary', type: 'button', onclick: () => openSheet(), text: label || 'Ajouter un rêve' });
const sampleBtn = () => h('button', { class: 'btn', type: 'button', onclick: addSamples, text: 'Essayer avec des exemples' });
const linkBtn = (text, fn) => h('button', { class: 'link', type: 'button', onclick: fn, text });

/* ---------- Accueil ---------- */
function greeting() {
  const hr = new Date().getHours();
  const w = hr >= 5 && hr < 18 ? 'Bonjour' : 'Bonsoir';
  return user.displayName ? `${w}, ${user.displayName}` : w;
}
/** Un point par rêve : plein quand il est réalisé. Chaque point ouvre le rêve. */
function dotMatrix() {
  const list = dreams.slice().sort((a, b) => a.createdAt - b.createdAt);
  const shown = list.slice(0, 180);
  const box = h('div', { class: 'dots', role: 'group', 'aria-label': 'Tous tes rêves : un point par rêve' });
  shown.forEach((d, i) => {
    const b = h('button', {
      class: 'dt' + (d.done ? ' on' : ''), type: 'button', title: d.title,
      'aria-label': (d.done ? 'Réalisé : ' : 'À réaliser : ') + d.title, onclick: () => openSheet(d),
    });
    if (!ui.revealed) { b.classList.add('in'); b.style.animationDelay = Math.min(i * 12, 700) + 'ms'; }
    box.append(b);
  });
  return box;
}
function bar(pct) { const i = h('i'); i.style.width = pct + '%'; return i; }
function catProgress() {
  const rows = categories.map((c) => {
    const l = dreams.filter((d) => d.cat === c.id);
    return { c, total: l.length, done: l.filter((d) => d.done).length };
  }).filter((x) => x.total > 0);
  if (!rows.length) return [];
  return [h('h2', { class: 'sec', text: 'Par catégorie' }),
    h('div', { class: 'list pad' }, rows.map((x) => {
      const row = h('div', { class: 'prow' },
        h('span', { class: 'pe', 'aria-hidden': 'true', text: x.c.emoji }),
        h('div', { class: 'pm' },
          h('div', { class: 'pl' }, h('span', { text: x.c.label }), h('span', { class: 'pc', text: `${x.done} sur ${x.total}` })),
          h('div', { class: 'track', 'aria-hidden': 'true' }, bar(Math.round(x.done / x.total * 100)))));
      row.style.setProperty('--h', hueOf(x.c));
      return row;
    }))];
}
function homeView() {
  const total = dreams.length, done = dreams.filter((d) => d.done).length;
  const out = [];
  const sub = !total ? 'Ton carnet est vide pour le moment.'
    : (done ? `${plural(done, 'rêve réalisé', 'rêves réalisés')} sur ${total}.` : `${plural(total, 'rêve', 'rêves')} à réaliser.`);
  out.push(h('section', { class: 'hero' },
    h('h1', { text: greeting() }),
    h('p', { class: 'lead', text: sub }),
    total ? dotMatrix() : null,
    total ? h('div', { class: 'legend' }, h('span', null, h('i', { class: 'dt on' }), 'Réalisé'), h('span', null, h('i', { class: 'dt' }), 'À réaliser')) : null));
  catProgress().forEach((n) => out.push(n));
  const last = user && user.lastExport ? new Date(user.lastExport + 'T00:00:00').getTime() : 0;
  const stale = total > 0 && (!last || Date.now() - last > 30 * 864e5);
  if (stale) out.push(h('div', { class: 'box' }, h('div', { text: last ? 'Ta dernière sauvegarde JSON date de plus de 30 jours.' : "Tu n'as pas encore de copie JSON de tes rêves." }),
    h('div', { class: 'btns' }, h('button', { class: 'btn', type: 'button', onclick: exportJson, text: 'Exporter une copie' }))));

  const rank = { haute: 0, moyenne: 1, basse: 2 };
  const next = dreams.filter((d) => !d.done).sort((a, b) =>
    (a.planned || '9999').localeCompare(b.planned || '9999') || ((rank[a.priority] ?? 1) - (rank[b.priority] ?? 1)) || (b.createdAt - a.createdAt)).slice(0, 4);
  out.push(h('div', { class: 'sec-head' }, h('h2', { class: 'sec', text: 'Prochains rêves' }),
    dreams.some((d) => !d.done) ? linkBtn('Tout voir', () => { ui.status = 'todo'; go('dreams'); }) : null));
  if (!ready) out.push(emptyBox('Chargement de ton carnet…'));
  else if (next.length) out.push(listBox(next));
  else out.push(emptyBox(total ? 'Tout est réalisé. Ajoute un nouveau rêve.' : 'Aucun rêve pour le moment.', total ? [addBtn()] : [addBtn(), sampleBtn()]));

  const fin = dreams.filter((d) => d.done).sort((a, b) => (b.doneAt || '').localeCompare(a.doneAt || '')).slice(0, 3);
  out.push(h('div', { class: 'sec-head' }, h('h2', { class: 'sec', text: 'Dernières réalisations' }),
    fin.length ? linkBtn('Tout voir', () => go('done')) : null));
  if (fin.length) out.push(listBox(fin));
  else out.push(emptyBox('Rien de réalisé pour le moment. Coche un rêve quand tu l\'as vécu.'));
  return out;
}

/* ---------- Mes rêves ---------- */
function filtered() {
  let l = dreams.slice();
  const q = ui.q.trim().toLowerCase();
  if (q) l = l.filter((d) => `${d.title} ${d.note} ${d.memory}`.toLowerCase().includes(q));
  if (ui.cat !== 'all') l = l.filter((d) => d.cat === ui.cat);
  if (ui.status === 'todo') l = l.filter((d) => !d.done);
  if (ui.status === 'done') l = l.filter((d) => d.done);
  const rank = { haute: 0, moyenne: 1, basse: 2 };
  const by = {
    recent: (a, b) => b.createdAt - a.createdAt,
    priority: (a, b) => ((rank[a.priority] ?? 1) - (rank[b.priority] ?? 1)) || (b.createdAt - a.createdAt),
    planned: (a, b) => (a.planned || '9999').localeCompare(b.planned || '9999'),
    alpha: (a, b) => a.title.localeCompare(b.title, 'fr'),
  };
  return l.sort(by[ui.sort] || by.recent);
}
function renderList() {
  const box = $('#list');
  if (!box) return;
  box.replaceChildren();
  if (!ready) { box.append(emptyBox('Chargement de ton carnet…')); return; }
  if (!dreams.length) { box.append(emptyBox('Ton carnet est vide. Écris le premier rêve que tu veux vivre.', [addBtn(), sampleBtn()])); return; }
  const l = filtered();
  if (!l.length) {
    box.append(emptyBox('Aucun rêve ne correspond à ces filtres.', [h('button', { class: 'btn', type: 'button', onclick: () => { ui.q = ''; ui.cat = 'all'; ui.status = 'all'; render(); }, text: 'Effacer les filtres' })]));
    return;
  }
  box.append(listBox(l));
}
function sel(opts, val, on, label) {
  const s = h('select', { class: 'field', 'aria-label': label, onchange: () => on(s.value) }, opts.map(([v, t]) => h('option', { value: v, text: t })));
  s.value = val;
  return s;
}
function dreamsView() {
  const search = h('input', { class: 'field', id: 'q', type: 'search', placeholder: 'Rechercher un rêve…', 'aria-label': 'Rechercher un rêve', value: ui.q, oninput: (e) => { ui.q = e.target.value; renderList(); } });
  const chips = h('div', { class: 'chips', role: 'group', 'aria-label': 'Catégories' },
    [{ id: 'all', emoji: '', label: 'Toutes' }].concat(categories).map((c) =>
      h('button', { class: 'chip', type: 'button', 'aria-pressed': String(ui.cat === c.id), text: (c.emoji ? c.emoji + ' ' : '') + c.label, onclick: () => { ui.cat = c.id; render(); } })));
  return [
    h('h1', { class: 'page', text: 'Mes rêves' }),
    h('div', { class: 'search' }, icon('search', 18), search),
    chips,
    h('div', { class: 'row' },
      sel([['all', 'Tous les statuts'], ['todo', 'À réaliser'], ['done', 'Réalisés']], ui.status, (v) => { ui.status = v; renderList(); }, 'Filtrer par statut'),
      sel([['recent', 'Plus récents'], ['priority', 'Priorité'], ['planned', 'Date prévue'], ['alpha', 'A → Z']], ui.sort, (v) => { ui.sort = v; renderList(); }, 'Trier')),
    h('div', { id: 'list' }),
  ];
}

/* ---------- Réalisés ---------- */
function doneView() {
  const l = dreams.filter((d) => d.done).sort((a, b) => (b.doneAt || '').localeCompare(a.doneAt || ''));
  const out = [h('h1', { class: 'page', text: 'Rêves réalisés' })];
  if (l.length) out.push(h('p', { class: 'lead', text: plural(l.length, 'rêve réalisé', 'rêves réalisés') + '.' }));
  if (!ready) out.push(emptyBox('Chargement de ton carnet…'));
  else if (!l.length) out.push(emptyBox('Aucun rêve réalisé pour le moment. Quand tu en coches un, il apparaît ici avec ton souvenir.'));
  else out.push(listBox(l));
  return out;
}

/* ---------- Réglages ---------- */
function settingsView() {
  const out = [h('h1', { class: 'page', text: 'Réglages' })];
  out.push(h('section', { class: 'group' },
    h('h2', { class: 'sec', text: 'Compte' }),
    h('p', { class: 'who', text: user.displayName ? `${user.displayName} · ${user.email}` : user.email }),
    h('div', { class: 'btns' },
      h('button', { class: 'btn', type: 'button', onclick: logout, text: 'Se déconnecter' }),
      h('button', { class: 'btn', type: 'button', onclick: changePassword, text: 'Changer le mot de passe' }),
      h('button', { class: 'btn danger', type: 'button', onclick: deleteAccount, text: 'Supprimer mon compte' }))));

  const rows = categories.map((c) => {
    const n = dreams.filter((d) => d.cat === c.id).length;
    const row = h('div', { class: 'catrow' },
      h('span', { class: 'e', 'aria-hidden': 'true', text: c.emoji }), h('span', { class: 'n', text: c.label }), h('span', { class: 'c', text: plural(n, 'rêve', 'rêves') }),
      h('button', { class: 'iconbtn sm ghost', type: 'button', title: 'Modifier', 'aria-label': 'Modifier la catégorie ' + c.label, onclick: () => openCategorySheet(c) }, icon('edit', 17)));
    row.style.setProperty('--h', hueOf(c));
    return row;
  });
  out.push(h('section', { class: 'group' },
    h('div', { class: 'sec-head' }, h('h2', { class: 'sec', text: 'Catégories' }),
      linkBtn('Ajouter', () => openCategorySheet())),
    h('div', { class: 'list pad' }, rows)));

  out.push(h('section', { class: 'group' },
    h('h2', { class: 'sec', text: 'Apparence' }),
    h('div', { class: 'seg', role: 'group', 'aria-label': 'Thème' },
      [['auto', 'Automatique'], ['light', 'Clair'], ['dark', 'Sombre']].map(([v, l]) =>
        h('button', { class: 'chip', type: 'button', 'aria-pressed': String(theme === v), text: l, onclick: () => setTheme(v) })))));

  out.push(h('section', { class: 'group' },
    h('h2', { class: 'sec', text: 'Sauvegarde' }),
    h('p', { class: 'hint', text: 'Tes rêves sont stockés dans ta base de données. Les mots de passe sont hachés et ne sont jamais enregistrés en clair.' }),
    h('p', { class: 'hint', text: 'Dernière sauvegarde JSON : ' + (user.lastExport ? fmt(user.lastExport) : 'aucune') }),
    h('div', { class: 'btns' },
      h('button', { class: 'btn', type: 'button', onclick: exportJson, text: 'Exporter en JSON' }),
      h('button', { class: 'btn', type: 'button', onclick: () => $('#file').click(), text: 'Importer un JSON' }),
      h('input', { id: 'file', type: 'file', accept: '.json,application/json', class: 'hidden', onchange: (e) => { const f = e.target.files && e.target.files[0]; if (f) importFile(f); e.target.value = ''; } }))));

  out.push(h('section', { class: 'group' },
    h('h2', { class: 'sec', text: 'Données' }),
    h('div', { class: 'btns' },
      h('button', { class: 'btn', type: 'button', onclick: addSamples, text: "Ajouter des rêves d'exemple" }),
      h('button', { class: 'btn danger', type: 'button', disabled: !dreams.length, text: ui.armedWipe ? 'Confirmer : tout supprimer' : 'Supprimer tous mes rêves',
        onclick: () => { if (!ui.armedWipe) { ui.armedWipe = true; render(); return; } ui.armedWipe = false; wipeAll(); } }))));
  return out;
}

/* ---------- Connexion / création de compte ---------- */
function authView() {
  const reg = ui.authMode === 'register';
  const email = h('input', { class: 'field', id: 'a-email', type: 'email', autocomplete: 'email', placeholder: 'Adresse e-mail', 'aria-label': 'Adresse e-mail', maxlength: '254', value: ui.authEmail, oninput: (e) => { ui.authEmail = e.target.value; } });
  const name = reg ? h('input', { class: 'field', id: 'a-name', autocomplete: 'given-name', placeholder: 'Prénom (facultatif)', 'aria-label': 'Prénom', maxlength: '60', value: ui.authName, oninput: (e) => { ui.authName = e.target.value; } }) : null;
  const pw = h('input', { class: 'field', id: 'a-pw', type: 'password', autocomplete: reg ? 'new-password' : 'current-password', maxlength: '72', placeholder: reg ? 'Mot de passe (10 caractères minimum)' : 'Mot de passe', 'aria-label': 'Mot de passe' });
  const err = h('div', { class: 'err', role: 'alert', text: ui.authMsg });
  const btn = h('button', { class: 'btn primary', type: 'submit', text: reg ? 'Créer mon compte' : 'Se connecter' });
  const form = h('form', {
    class: 'authform', novalidate: true,
    onsubmit: async (e) => {
      e.preventDefault();
      btn.disabled = true; err.textContent = '';
      try {
        const body = { email: ui.authEmail.trim(), password: pw.value };
        if (reg && ui.authName.trim()) body.displayName = ui.authName.trim();
        const r = await api('POST', reg ? '/auth/register' : '/auth/login', body);
        user = r.user; ui.authMsg = ''; ui.authEmail = ''; ui.authName = ''; ui.tab = 'home'; ui.revealed = false;
        if (user.theme && user.theme !== theme) { theme = user.theme; try { localStorage.setItem('dreaming-theme', theme); } catch (x) { /* ignoré */ } applyTheme(); }
        await loadAll();
        render();
      } catch (ex) { err.textContent = ex.message; btn.disabled = false; }
    },
  }, email, name, pw, err, btn);
  return [h('section', { class: 'auth' },
    h('span', { class: 'auth-logo' }, icon('logo', 34)),
    h('h1', { text: 'Dreaming' }),
    h('p', { class: 'tag', text: 'Écris ce que tu veux vivre un jour. Ton carnet reste privé.' }),
    h('div', { class: 'seg center', role: 'group', 'aria-label': 'Mode' },
      h('button', { class: 'chip', type: 'button', 'aria-pressed': String(!reg), text: 'Connexion', onclick: () => { ui.authMode = 'login'; ui.authMsg = ''; render(); } }),
      h('button', { class: 'chip', type: 'button', 'aria-pressed': String(reg), text: 'Créer un compte', onclick: () => { ui.authMode = 'register'; ui.authMsg = ''; render(); } })),
    form,
    reg ? h('p', { class: 'fine', text: "Ton mot de passe est haché avant d'être enregistré. Personne ne peut le lire." }) : null)];
}

/* ---------- Rendu ---------- */
const TABS = { home: ['home', 'Accueil'], dreams: ['list', 'Rêves'], done: ['check', 'Réalisés'], settings: ['gear', 'Réglages'] };
const VIEWS = { home: homeView, dreams: dreamsView, done: doneView, settings: settingsView };
function render() {
  document.body.classList.toggle('authed', !!user);
  const view = $('#view');
  const ae = document.activeElement;
  const aid = user && ae && ae.id;
  const pos = ae && ae.selectionStart;
  if (user && ui.tab !== 'settings') ui.armedWipe = false;
  let nodes;
  if (booting) nodes = [h('div', { class: 'loading', text: 'Chargement…' })];
  else if (!user) nodes = authView();
  else nodes = VIEWS[ui.tab]();
  view.replaceChildren(...nodes);
  if (user && ui.tab === 'home' && ready) ui.revealed = true; // l'animation des points ne joue qu'une fois
  if (user && ui.tab === 'dreams') renderList();
  document.querySelectorAll('.tab').forEach((t) => t.setAttribute('aria-current', user && t.dataset.tab === ui.tab ? 'page' : 'false'));
  if (aid) {
    const el = document.getElementById(aid);
    if (el && el.tagName !== 'BUTTON') { el.focus(); try { if (pos !== null && pos !== undefined) el.setSelectionRange(pos, pos); } catch (e) { /* champ sans sélection */ } }
  }
}
function go(tab) { ui.tab = tab; render(); window.scrollTo(0, 0); }

/* ---------- Démarrage ---------- */
document.querySelectorAll('.tab').forEach((t) => {
  const k = t.dataset.tab;
  t.append(h('span', { class: 'ico' }, icon(TABS[k][0], 22)), h('span', { text: TABS[k][1] }));
  t.addEventListener('click', () => go(k));
});
$('#fab').prepend(icon('plus', 22));
$('#fab').addEventListener('click', () => openSheet());
$('#brandIcon').append(icon('logo', 26));
$('#sideIcon').append(icon('logo', 24));
$('#themeBtn').addEventListener('click', () => setTheme(effectiveTheme() === 'dark' ? 'light' : 'dark'));
$('#sheet').addEventListener('click', (e) => { if (e.target === e.currentTarget) requestClose(); });
$('#sheet').addEventListener('cancel', (e) => { if (sheetGuard && !sheetGuard()) e.preventDefault(); });
$('#sheet').addEventListener('close', () => { sheetGuard = null; });
document.addEventListener('keydown', (e) => {
  // raccourci : « n » ouvre un nouveau rêve (hors champ de saisie)
  if (e.key !== 'n' || e.ctrlKey || e.metaKey || e.altKey || !user || $('#sheet').open) return;
  const t = e.target;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
  e.preventDefault(); openSheet();
});
applyTheme();
render();
(async function boot() {
  try {
    const r = await api('GET', '/auth/me');
    user = r.user;
    if (user.theme && user.theme !== theme) { theme = user.theme; try { localStorage.setItem('dreaming-theme', theme); } catch (e) { /* ignoré */ } applyTheme(); }
    await loadAll();
  } catch (e) {
    user = null;
    if (e.status !== 401) ui.authMsg = e.message;
  }
  booting = false;
  render();
})();
