'use strict';
const { badRequest } = require('./errors');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function reqString(v, label, min, max) {
  if (typeof v !== 'string') throw badRequest(`${label} est obligatoire.`);
  const s = v.trim();
  if (s.length < min) throw badRequest(`${label} est obligatoire.`);
  if (s.length > max) throw badRequest(`${label} est trop long (${max} caractères maximum).`);
  return s;
}
function optString(v, label, max) {
  if (v === undefined || v === null) return '';
  if (typeof v !== 'string') throw badRequest(`${label} est invalide.`);
  const s = v.trim();
  if (s.length > max) throw badRequest(`${label} est trop long (${max} caractères maximum).`);
  return s;
}
function uuid(v, label) {
  if (typeof v !== 'string' || !UUID.test(v)) throw badRequest(`${label} est invalide.`);
  return v.toLowerCase();
}
function date(v, label) {
  if (v === undefined || v === null || v === '') return null;
  if (typeof v !== 'string' || !DATE.test(v)) throw badRequest(`${label} est invalide (format AAAA-MM-JJ).`);
  const d = new Date(`${v}T00:00:00Z`);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== v) throw badRequest(`${label} est invalide.`);
  return v;
}
function oneOf(v, list, label) {
  if (!list.includes(v)) throw badRequest(`${label} est invalide.`);
  return v;
}
function bool(v, label) {
  if (typeof v !== 'boolean') throw badRequest(`${label} est invalide.`);
  return v;
}
function int(v, label, min, max) {
  if (!Number.isInteger(v) || v < min || v > max) throw badRequest(`${label} est invalide.`);
  return v;
}
function email(v) {
  const s = reqString(v, "L'adresse e-mail", 3, 254).toLowerCase();
  if (!EMAIL.test(s)) throw badRequest("L'adresse e-mail est invalide.");
  return s;
}
function newPassword(v) {
  if (typeof v !== 'string') throw badRequest('Le mot de passe est obligatoire.');
  if (v.length < 10) throw badRequest('Le mot de passe doit contenir au moins 10 caractères.');
  if (Buffer.byteLength(v, 'utf8') > 72) throw badRequest('Le mot de passe est trop long (72 octets maximum).');
  return v;
}
function anyPassword(v) {
  if (typeof v !== 'string' || !v || Buffer.byteLength(v, 'utf8') > 72) throw badRequest('Mot de passe invalide.');
  return v;
}
function body(b) {
  if (!b || typeof b !== 'object' || Array.isArray(b)) throw badRequest('Corps de requête invalide.');
  return b;
}

module.exports = { reqString, optString, uuid, date, oneOf, bool, int, email, newPassword, anyPassword, body };
