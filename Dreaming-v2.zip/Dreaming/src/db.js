'use strict';
const { Pool } = require('pg');
const config = require('./config');

const pool = new Pool({
  connectionString: config.databaseUrl,
  ssl: config.pgSsl ? { rejectUnauthorized: false } : false,
  max: 10,
});
pool.on('error', (e) => console.error('Erreur du pool PostgreSQL :', e.message));

const query = (text, params) => pool.query(text, params);

/** Exécute fn(client) dans une transaction (commit/rollback automatiques). */
async function tx(fn) {
  const client = await pool.connect();
  try {
    await client.query('begin');
    const result = await fn(client);
    await client.query('commit');
    return result;
  } catch (e) {
    try { await client.query('rollback'); } catch (_) { /* ignoré */ }
    throw e;
  } finally {
    client.release();
  }
}

module.exports = { pool, query, tx };
