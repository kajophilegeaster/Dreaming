'use strict';
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const { rateLimit } = require('express-rate-limit');
const config = require('./config');
const { pool, query } = require('./db');
const { HttpError, wrap } = require('./errors');
const { requireAuth } = require('./auth');

function createApp() {
  const app = express();
  app.disable('x-powered-by');
  if (config.prod) app.set('trust proxy', 1); // Render place un proxy devant l'app

  // En-têtes de sécurité + CSP stricte : aucun script ni style inline, uniquement notre origine + Google Fonts
  app.use(helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", 'https://fonts.googleapis.com'],
        fontSrc: ['https://fonts.gstatic.com'],
        imgSrc: ["'self'", 'data:'],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'none'"],
      },
    },
    crossOriginEmbedderPolicy: false,
  }));

  app.get('/healthz', wrap(async (req, res) => {
    await query('SELECT 1');
    res.json({ ok: true });
  }));

  // Import : corps JSON plus large que le reste de l'API
  app.use('/api/import', express.json({ limit: '3mb' }));
  app.use(express.json({ limit: '100kb' }));
  app.use(cookieParser());

  // Anti-CSRF : cookie SameSite=Strict + JSON obligatoire + Origin identique à l'hôte
  app.use('/api', (req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    const origin = req.get('origin');
    if (origin) {
      let host = null;
      try { host = new URL(origin).host; } catch (_) { /* origine invalide */ }
      if (host !== req.get('host')) return next(new HttpError(403, 'forbidden', 'Origine refusée.'));
    }
    if (['POST', 'PATCH', 'PUT'].includes(req.method) && !req.is('application/json')) {
      return next(new HttpError(415, 'unsupported_media_type', 'Le contenu doit être au format JSON.'));
    }
    next();
  });

  const limitMsg = { error: { code: 'rate_limited', message: 'Trop de tentatives. Réessaie dans quelques minutes.' } };
  const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: config.authRateMax, standardHeaders: 'draft-7', legacyHeaders: false, message: limitMsg });
  const apiLimiter = rateLimit({ windowMs: 60 * 1000, limit: config.apiRateMax, standardHeaders: 'draft-7', legacyHeaders: false, message: limitMsg });

  app.use('/api', apiLimiter);
  app.use('/api/auth/login', authLimiter);
  app.use('/api/auth/register', authLimiter);
  app.use('/api/auth/password', authLimiter);

  app.use('/api/auth', require('./routes/auth'));
  app.use('/api/categories', requireAuth, require('./routes/categories'));
  app.use('/api/dreams', requireAuth, require('./routes/dreams'));
  app.use('/api', requireAuth, require('./routes/data'));

  app.use('/api', (req, res, next) => next(new HttpError(404, 'not_found', 'Route inconnue.')));

  app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: config.prod ? '1h' : 0 }));

  // Gestion d'erreurs : jamais de détails internes envoyés au client
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    let status = err.status || 500;
    let code = err.code && typeof err.code === 'string' && err.status ? err.code : 'server_error';
    let message = err.status && err.status < 500 ? err.message : 'Erreur du serveur. Réessaie dans un instant.';

    if (err.type === 'entity.too.large') { status = 413; code = 'too_large'; message = 'Contenu trop volumineux.'; }
    else if (err.type === 'entity.parse.failed') { status = 400; code = 'invalid_json'; message = 'JSON invalide.'; }
    else if (!err.status && typeof err.code === 'string' && /^\w{5}$/.test(err.code)) {
      // erreurs PostgreSQL connues
      const map = {
        '23503': [400, 'invalid_reference', 'Référence introuvable (catégorie inexistante ?).'],
        '23505': [409, 'duplicate', 'Cet élément existe déjà.'],
        '23514': [400, 'invalid_value', 'Valeur refusée par la base de données.'],
        '22P02': [400, 'invalid_value', 'Valeur invalide.'],
        '22007': [400, 'invalid_value', 'Date invalide.'],
        '22008': [400, 'invalid_value', 'Date invalide.'],
      };
      if (map[err.code]) [status, code, message] = map[err.code];
    }
    if (status >= 500) console.error(err);
    res.status(status).json({ error: { code, message } });
  });

  return app;
}

module.exports = { createApp };

if (require.main === module) {
  const app = createApp();
  const server = app.listen(config.port, () => console.log(`Dreaming écoute sur le port ${config.port}`));
  const stop = () => server.close(() => pool.end().then(() => process.exit(0)));
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}
