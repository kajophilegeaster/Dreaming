'use strict';
const fs = require('fs');
const path = require('path');
const { pool } = require('./db');

async function migrate() {
  const sql = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
  await pool.query(sql);
}

module.exports = { migrate };

if (require.main === module) {
  migrate()
    .then(() => { console.log('Schéma appliqué.'); return pool.end(); })
    .catch((e) => { console.error('Échec de la migration :', e.message); process.exit(1); });
}
