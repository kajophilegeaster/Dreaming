'use strict';
const express = require('express');
const config = require('../config');
const { query, tx } = require('../db');
const { HttpError, badRequest, wrap } = require('../errors');
const v = require('../validate');

const router = express.Router();
const MAX_IMPORT = 500;

router.get('/export', wrap(async (req, res) => {
  const [cats, dreams] = await Promise.all([
    query('SELECT label, emoji, hue FROM categories WHERE user_id = $1 ORDER BY position, created_at', [req.user.id]),
    query(
      `SELECT d.title, c.label AS category, d.note, d.priority,
              to_char(d.planned_date, 'YYYY-MM-DD') AS "plannedDate", d.is_done AS "isDone",
              to_char(d.done_at, 'YYYY-MM-DD') AS "doneAt", d.memory, d.created_at AS "createdAt"
         FROM dreams d LEFT JOIN categories c ON c.id = d.category_id AND c.user_id = d.user_id
        WHERE d.user_id = $1 ORDER BY d.created_at`, [req.user.id]),
  ]);
  res.setHeader('Content-Disposition', 'attachment; filename="dreaming-sauvegarde.json"');
  res.json({ app: 'dreaming', version: 2, exportedAt: new Date().toISOString(), categories: cats.rows, dreams: dreams.rows });
}));

/** Accepte le format v2 (cette API) et l'ancien format v1 (version artifact : cat/planned/done). */
router.post('/import', wrap(async (req, res) => {
  const b = v.body(req.body);
  if (!Array.isArray(b.dreams)) throw badRequest('Fichier invalide : la liste "dreams" est absente.');
  if (b.dreams.length > MAX_IMPORT) throw badRequest(`Import limité à ${MAX_IMPORT} rêves à la fois.`);

  // v1 : les rêves pointent vers l'id d'une catégorie ; on retrouve son nom
  const labelById = new Map();
  const wantedCats = new Map(); // label -> {emoji, hue}
  for (const c of Array.isArray(b.categories) ? b.categories : []) {
    if (!c || typeof c.label !== 'string' || !c.label.trim()) continue;
    const label = c.label.trim().slice(0, 40);
    if (typeof c.id === 'string') labelById.set(c.id, label);
    wantedCats.set(label.toLowerCase(), {
      label,
      emoji: typeof c.emoji === 'string' && c.emoji.trim() ? c.emoji.trim().slice(0, 8) : '✦',
      hue: Number.isInteger(c.hue) && c.hue >= 0 && c.hue <= 360 ? c.hue : Math.floor(Math.random() * 361),
    });
  }

  const items = [];
  let skipped = 0;
  for (const x of b.dreams) {
    try {
      if (!x || typeof x !== 'object') throw new Error('x');
      const catLabel = typeof x.category === 'string' ? x.category.trim().slice(0, 40)
        : (typeof x.cat === 'string' ? labelById.get(x.cat) || '' : '');
      const isDone = typeof x.isDone === 'boolean' ? x.isDone : x.done === true;
      const created = new Date(x.createdAt);
      items.push({
        title: v.reqString(x.title, 'Le titre', 1, 160),
        catLabel,
        note: v.optString(x.note, 'La note', 2000),
        priority: ['haute', 'moyenne', 'basse'].includes(x.priority) ? x.priority : 'moyenne',
        plannedDate: v.date(x.plannedDate !== undefined ? x.plannedDate : x.planned, 'La date prévue'),
        isDone,
        doneAt: isDone ? v.date(x.doneAt, 'La date de réalisation') : null,
        memory: v.optString(x.memory, 'Le souvenir', 2000),
        createdAt: Number.isNaN(created.getTime()) ? new Date() : created,
      });
    } catch (_) {
      skipped++;
    }
  }

  const result = await tx(async (c) => {
    const { rows: existingCats } = await c.query('SELECT id, label FROM categories WHERE user_id = $1', [req.user.id]);
    const catId = new Map(existingCats.map((r) => [r.label.toLowerCase(), r.id]));

    // catégories manquantes (noms utilisés par les rêves ou déclarés dans le fichier)
    for (const it of items) {
      if (it.catLabel && !wantedCats.has(it.catLabel.toLowerCase())) {
        wantedCats.set(it.catLabel.toLowerCase(), { label: it.catLabel, emoji: '✦', hue: Math.floor(Math.random() * 361) });
      }
    }
    let created = 0;
    let categoriesSkipped = 0;
    for (const [key, cat] of wantedCats) {
      if (catId.has(key)) continue;
      if (catId.size >= config.maxCategories) { categoriesSkipped++; continue; }
      const { rows } = await c.query(
        `INSERT INTO categories (user_id, label, emoji, hue, position)
         VALUES ($1, $2, $3, $4, (SELECT coalesce(max(position), 0) + 1 FROM categories WHERE user_id = $1)) RETURNING id`,
        [req.user.id, cat.label, cat.emoji, cat.hue]);
      catId.set(key, rows[0].id);
      created++;
    }

    const { rows: cnt } = await c.query('SELECT count(*)::int AS n FROM dreams WHERE user_id = $1', [req.user.id]);
    if (cnt[0].n + items.length > config.maxDreams) throw new HttpError(409, 'limit_reached', `Limite de ${config.maxDreams} rêves atteinte.`);

    // évite les doublons quand on réimporte sa propre sauvegarde
    const { rows: ex } = await c.query('SELECT lower(title) AS t, created_at FROM dreams WHERE user_id = $1', [req.user.id]);
    const seen = new Set(ex.map((r) => `${r.t}|${r.created_at.getTime()}`));

    let imported = 0;
    for (const it of items) {
      const key = `${it.title.toLowerCase()}|${it.createdAt.getTime()}`;
      if (seen.has(key)) { skipped++; continue; }
      seen.add(key);
      await c.query(
        `INSERT INTO dreams (user_id, category_id, title, note, priority, planned_date, is_done, done_at, memory, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [req.user.id, it.catLabel ? catId.get(it.catLabel.toLowerCase()) || null : null, it.title, it.note, it.priority,
          it.plannedDate, it.isDone, it.doneAt, it.memory, it.createdAt]);
      imported++;
    }
    return { imported, skipped, categoriesCreated: created, categoriesSkipped };
  });
  res.json(result);
}));

module.exports = router;
