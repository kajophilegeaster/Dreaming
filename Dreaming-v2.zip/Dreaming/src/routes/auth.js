'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const config = require('../config');
const { query, tx } = require('../db');
const { HttpError, wrap } = require('../errors');
const v = require('../validate');
const { USER_COLS, setSession, clearSession, publicUser, requireAuth } = require('../auth');

const router = express.Router();

const DEFAULT_CATEGORIES = [
  ['Voyages', '✈️', 205], ['Défis', '🎯', 12], ['Carrière', '💼', 38], ['Apprentissage', '📚', 262],
  ['Famille', '❤️', 340], ['Bien-être', '🌿', 150], ['Créatif', '🎨', 300], ['Autre', '✨', 50],
];

// Hash factice : le temps de réponse ne révèle pas si un e-mail existe
const DUMMY_HASH = bcrypt.hashSync('dreaming-dummy-password', 4);

router.post('/register', wrap(async (req, res) => {
  const b = v.body(req.body);
  const email = v.email(b.email);
  const password = v.newPassword(b.password);
  const displayName = b.displayName ? v.reqString(b.displayName, 'Le prénom', 1, 60) : null;
  const hash = await bcrypt.hash(password, config.bcryptCost);

  let user;
  try {
    user = await tx(async (c) => {
      const { rows } = await c.query(
        `INSERT INTO users (email, password_hash, display_name) VALUES ($1, $2, $3) RETURNING ${USER_COLS}`,
        [email, hash, displayName],
      );
      const u = rows[0];
      for (let i = 0; i < DEFAULT_CATEGORIES.length; i++) {
        const [label, emoji, hue] = DEFAULT_CATEGORIES[i];
        await c.query(
          'INSERT INTO categories (user_id, label, emoji, hue, position) VALUES ($1, $2, $3, $4, $5)',
          [u.id, label, emoji, hue, i + 1],
        );
      }
      return u;
    });
  } catch (e) {
    if (e.code === '23505') throw new HttpError(409, 'email_taken', 'Un compte existe déjà avec cette adresse e-mail.');
    throw e;
  }
  setSession(res, user);
  res.status(201).json({ user: publicUser(user) });
}));

router.post('/login', wrap(async (req, res) => {
  const b = v.body(req.body);
  const email = v.email(b.email);
  const password = v.anyPassword(b.password);
  const { rows } = await query(`SELECT ${USER_COLS}, password_hash FROM users WHERE lower(email) = $1`, [email]);
  const row = rows[0];
  const ok = await bcrypt.compare(password, row ? row.password_hash : DUMMY_HASH);
  if (!row || !ok) throw new HttpError(401, 'bad_credentials', 'E-mail ou mot de passe incorrect.');
  setSession(res, row);
  res.json({ user: publicUser(row) });
}));

router.post('/logout', (req, res) => {
  clearSession(res);
  res.json({ ok: true });
});

router.get('/me', requireAuth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

router.patch('/me', requireAuth, wrap(async (req, res) => {
  const b = v.body(req.body);
  const sets = [];
  const vals = [req.user.id];
  const add = (col, val) => { vals.push(val); sets.push(`${col} = $${vals.length}`); };
  if (b.displayName !== undefined) add('display_name', b.displayName === null || b.displayName === '' ? null : v.reqString(b.displayName, 'Le prénom', 1, 60));
  if (b.theme !== undefined) add('theme', v.oneOf(b.theme, ['dark', 'light', 'auto'], 'Le thème'));
  if (b.lastExport !== undefined) add('last_export', v.date(b.lastExport, 'La date de sauvegarde'));
  if (!sets.length) throw new HttpError(400, 'invalid_request', 'Aucune modification.');
  const { rows } = await query(`UPDATE users SET ${sets.join(', ')} WHERE id = $1 RETURNING ${USER_COLS}`, vals);
  res.json({ user: publicUser(rows[0]) });
}));

router.post('/password', requireAuth, wrap(async (req, res) => {
  const b = v.body(req.body);
  const current = v.anyPassword(b.current);
  const next = v.newPassword(b.next);
  const { rows: found } = await query('SELECT password_hash FROM users WHERE id = $1', [req.user.id]);
  if (!(await bcrypt.compare(current, found[0].password_hash))) {
    throw new HttpError(403, 'bad_credentials', 'Le mot de passe actuel est incorrect.');
  }
  const hash = await bcrypt.hash(next, config.bcryptCost);
  // token_version + 1 : toutes les autres sessions sont déconnectées
  const { rows } = await query(
    `UPDATE users SET password_hash = $2, token_version = token_version + 1 WHERE id = $1 RETURNING ${USER_COLS}`,
    [req.user.id, hash],
  );
  setSession(res, rows[0]);
  res.json({ ok: true });
}));

router.delete('/me', requireAuth, wrap(async (req, res) => {
  const b = v.body(req.body);
  const password = v.anyPassword(b.password);
  const { rows } = await query('SELECT password_hash FROM users WHERE id = $1', [req.user.id]);
  if (!(await bcrypt.compare(password, rows[0].password_hash))) {
    throw new HttpError(403, 'bad_credentials', 'Le mot de passe est incorrect.');
  }
  await query('DELETE FROM users WHERE id = $1', [req.user.id]); // cascade : catégories et rêves
  clearSession(res);
  res.json({ ok: true });
}));

module.exports = router;
