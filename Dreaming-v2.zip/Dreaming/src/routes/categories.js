'use strict';
const express = require('express');
const config = require('../config');
const { query } = require('../db');
const { HttpError, badRequest, notFound, wrap } = require('../errors');
const v = require('../validate');

const router = express.Router();
const COLS = 'id, label, emoji, hue, position';

router.get('/', wrap(async (req, res) => {
  const { rows } = await query(`SELECT ${COLS} FROM categories WHERE user_id = $1 ORDER BY position, created_at`, [req.user.id]);
  res.json({ categories: rows });
}));

router.post('/', wrap(async (req, res) => {
  const b = v.body(req.body);
  const label = v.reqString(b.label, 'Le nom', 1, 40);
  const emoji = b.emoji ? v.reqString(b.emoji, "L'emoji", 1, 8) : '✦';
  const hue = b.hue === undefined ? Math.floor(Math.random() * 361) : v.int(b.hue, 'La teinte', 0, 360);
  const { rows: cnt } = await query('SELECT count(*)::int AS n, coalesce(max(position), 0) AS pos FROM categories WHERE user_id = $1', [req.user.id]);
  if (cnt[0].n >= config.maxCategories) throw new HttpError(409, 'limit_reached', `Limite de ${config.maxCategories} catégories atteinte.`);
  const { rows } = await query(
    `INSERT INTO categories (user_id, label, emoji, hue, position) VALUES ($1, $2, $3, $4, $5) RETURNING ${COLS}`,
    [req.user.id, label, emoji, hue, cnt[0].pos + 1],
  );
  res.status(201).json({ category: rows[0] });
}));

router.patch('/:id', wrap(async (req, res) => {
  const id = v.uuid(req.params.id, 'La catégorie');
  const b = v.body(req.body);
  const sets = [];
  const vals = [id, req.user.id];
  const add = (col, val) => { vals.push(val); sets.push(`${col} = $${vals.length}`); };
  if (b.label !== undefined) add('label', v.reqString(b.label, 'Le nom', 1, 40));
  if (b.emoji !== undefined) add('emoji', v.reqString(b.emoji, "L'emoji", 1, 8));
  if (b.hue !== undefined) add('hue', v.int(b.hue, 'La teinte', 0, 360));
  if (b.position !== undefined) add('position', v.int(b.position, 'La position', 0, 1000));
  if (!sets.length) throw badRequest('Aucune modification.');
  const { rows } = await query(`UPDATE categories SET ${sets.join(', ')} WHERE id = $1 AND user_id = $2 RETURNING ${COLS}`, vals);
  if (!rows[0]) throw notFound('Catégorie introuvable.');
  res.json({ category: rows[0] });
}));

router.delete('/:id', wrap(async (req, res) => {
  const id = v.uuid(req.params.id, 'La catégorie');
  // les rêves liés gardent leur contenu : category_id passe à NULL (clé étrangère)
  const { rowCount } = await query('DELETE FROM categories WHERE id = $1 AND user_id = $2', [id, req.user.id]);
  if (!rowCount) throw notFound('Catégorie introuvable.');
  res.json({ ok: true });
}));

module.exports = router;
