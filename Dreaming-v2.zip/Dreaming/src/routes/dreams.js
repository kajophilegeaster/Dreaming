'use strict';
const express = require('express');
const config = require('../config');
const { query } = require('../db');
const { HttpError, badRequest, notFound, wrap } = require('../errors');
const v = require('../validate');

const router = express.Router();

const COLS = `id, category_id AS "categoryId", title, note, priority,
  to_char(planned_date, 'YYYY-MM-DD') AS "plannedDate", is_done AS "isDone",
  to_char(done_at, 'YYYY-MM-DD') AS "doneAt", memory,
  created_at AS "createdAt", updated_at AS "updatedAt"`;

/** Valide le corps et renvoie { colonne: valeur } (colonnes issues d'une liste fixe, jamais du client). */
function parse(b, partial) {
  v.body(b);
  const o = {};
  if (!partial || b.title !== undefined) o.title = v.reqString(b.title, 'Le titre', 1, 160);
  if (b.categoryId !== undefined) o.category_id = (b.categoryId === null || b.categoryId === '') ? null : v.uuid(b.categoryId, 'La catégorie');
  if (b.note !== undefined) o.note = v.optString(b.note, 'La note', 2000);
  if (b.priority !== undefined) o.priority = v.oneOf(b.priority, ['haute', 'moyenne', 'basse'], 'La priorité');
  if (b.plannedDate !== undefined) o.planned_date = v.date(b.plannedDate, 'La date prévue');
  if (b.isDone !== undefined) o.is_done = v.bool(b.isDone, 'Le statut');
  if (b.doneAt !== undefined) o.done_at = v.date(b.doneAt, 'La date de réalisation');
  if (b.memory !== undefined) o.memory = v.optString(b.memory, 'Le souvenir', 2000);
  return o;
}

const SORTS = {
  recent: 'created_at DESC',
  priority: "array_position(ARRAY['haute','moyenne','basse'], priority), created_at DESC",
  planned: 'planned_date ASC NULLS LAST, created_at DESC',
  alpha: 'lower(title) ASC',
};

router.get('/', wrap(async (req, res) => {
  const where = ['user_id = $1'];
  const vals = [req.user.id];
  const q = typeof req.query.q === 'string' ? req.query.q.trim().slice(0, 200) : '';
  if (q) { vals.push(q); where.push(`search @@ websearch_to_tsquery('french', $${vals.length})`); }
  if (req.query.categoryId) { vals.push(v.uuid(req.query.categoryId, 'La catégorie')); where.push(`category_id = $${vals.length}`); }
  if (req.query.status === 'todo') where.push('NOT is_done');
  if (req.query.status === 'done') where.push('is_done');
  const order = SORTS[req.query.sort] || SORTS.recent;
  const { rows } = await query(
    `SELECT ${COLS} FROM dreams WHERE ${where.join(' AND ')} ORDER BY ${order} LIMIT ${config.maxDreams}`, vals);
  res.json({ dreams: rows });
}));

router.post('/', wrap(async (req, res) => {
  const o = parse(req.body, false);
  const { rows: cnt } = await query('SELECT count(*)::int AS n FROM dreams WHERE user_id = $1', [req.user.id]);
  if (cnt[0].n >= config.maxDreams) throw new HttpError(409, 'limit_reached', `Limite de ${config.maxDreams} rêves atteinte.`);
  const keys = Object.keys(o);
  const cols = ['user_id', ...keys];
  const vals = [req.user.id, ...keys.map((k) => o[k])];
  const ph = vals.map((_, i) => `$${i + 1}`);
  const { rows } = await query(`INSERT INTO dreams (${cols.join(', ')}) VALUES (${ph.join(', ')}) RETURNING ${COLS}`, vals);
  res.status(201).json({ dream: rows[0] });
}));

router.patch('/:id', wrap(async (req, res) => {
  const id = v.uuid(req.params.id, 'Le rêve');
  const o = parse(req.body, true);
  const keys = Object.keys(o);
  if (!keys.length) throw badRequest('Aucune modification.');
  const sets = keys.map((k, i) => `${k} = $${i + 3}`);
  const vals = [id, req.user.id, ...keys.map((k) => o[k])];
  const { rows } = await query(`UPDATE dreams SET ${sets.join(', ')} WHERE id = $1 AND user_id = $2 RETURNING ${COLS}`, vals);
  if (!rows[0]) throw notFound('Rêve introuvable.');
  res.json({ dream: rows[0] });
}));

router.delete('/:id', wrap(async (req, res) => {
  const id = v.uuid(req.params.id, 'Le rêve');
  const { rowCount } = await query('DELETE FROM dreams WHERE id = $1 AND user_id = $2', [id, req.user.id]);
  if (!rowCount) throw notFound('Rêve introuvable.');
  res.json({ ok: true });
}));

router.delete('/', wrap(async (req, res) => {
  const { rowCount } = await query('DELETE FROM dreams WHERE user_id = $1', [req.user.id]);
  res.json({ deleted: rowCount });
}));

module.exports = router;
