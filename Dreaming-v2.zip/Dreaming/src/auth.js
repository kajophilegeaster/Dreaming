'use strict';
const jwt = require('jsonwebtoken');
const config = require('./config');
const { query } = require('./db');
const { HttpError, wrap } = require('./errors');

const USER_COLS = `id, email, display_name AS "displayName", theme,
  to_char(last_export, 'YYYY-MM-DD') AS "lastExport", token_version, created_at AS "createdAt"`;

function sign(user) {
  return jwt.sign({ sub: user.id, v: user.token_version }, config.jwtSecret, {
    algorithm: 'HS256',
    expiresIn: `${config.sessionDays}d`,
  });
}

/** Pose le cookie de session : httpOnly (illisible par JS), SameSite=Strict, Secure en production. */
function setSession(res, user) {
  res.cookie(config.cookieName, sign(user), {
    httpOnly: true,
    secure: config.prod,
    sameSite: 'strict',
    maxAge: config.sessionDays * 24 * 3600 * 1000,
    path: '/',
  });
}
function clearSession(res) {
  res.clearCookie(config.cookieName, { httpOnly: true, secure: config.prod, sameSite: 'strict', path: '/' });
}

/** Vue publique d'un utilisateur (jamais de hash ni de token_version). */
function publicUser(u) {
  return { id: u.id, email: u.email, displayName: u.displayName, theme: u.theme, lastExport: u.lastExport, createdAt: u.createdAt };
}

const requireAuth = wrap(async (req, res, next) => {
  const token = req.cookies && req.cookies[config.cookieName];
  if (!token) throw new HttpError(401, 'unauthenticated', 'Connexion requise.');
  let payload;
  try {
    payload = jwt.verify(token, config.jwtSecret, { algorithms: ['HS256'] });
  } catch (_) {
    throw new HttpError(401, 'unauthenticated', 'Ta session a expiré. Reconnecte-toi.');
  }
  const { rows } = await query(`SELECT ${USER_COLS} FROM users WHERE id = $1`, [payload.sub]);
  const user = rows[0];
  // token_version change quand le mot de passe change : les anciennes sessions deviennent invalides
  if (!user || user.token_version !== payload.v) {
    throw new HttpError(401, 'unauthenticated', 'Ta session a expiré. Reconnecte-toi.');
  }
  req.user = user;
  next();
});

module.exports = { USER_COLS, setSession, clearSession, publicUser, requireAuth };
