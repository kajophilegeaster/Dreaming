'use strict';
const fs = require('fs');
const path = require('path');

// Chargement minimal d'un fichier .env (sans dépendance externe)
const envFile = path.join(__dirname, '..', '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if (m && !(m[1] in process.env)) {
      process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
    }
  }
}

const env = process.env;
const prod = env.NODE_ENV === 'production';

const config = {
  prod,
  port: Number(env.PORT) || 3000,
  databaseUrl: env.DATABASE_URL,
  pgSsl: env.PGSSL === 'true',
  jwtSecret: env.JWT_SECRET,
  bcryptCost: Number(env.BCRYPT_COST) || 12,
  authRateMax: Number(env.AUTH_RATE_MAX) || 20,
  apiRateMax: Number(env.API_RATE_MAX) || 300,
  cookieName: 'dreaming_session',
  sessionDays: 7,
  maxDreams: 5000,
  maxCategories: 50,
};

if (!config.databaseUrl) {
  throw new Error('DATABASE_URL est manquant (voir .env.example).');
}
if (!config.jwtSecret || config.jwtSecret.length < 32) {
  throw new Error('JWT_SECRET est manquant ou trop court (32 caractères minimum).');
}

module.exports = config;
