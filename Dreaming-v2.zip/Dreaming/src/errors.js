'use strict';

class HttpError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}
const badRequest = (message, code = 'invalid_request') => new HttpError(400, code, message);
const notFound = (message = 'Introuvable.') => new HttpError(404, 'not_found', message);

/** Évite d'écrire try/catch dans chaque route. */
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

module.exports = { HttpError, badRequest, notFound, wrap };
